# SaberShader 1.0.3

Native Blender 5.1.1 shading add-on with profile-based material creation, texture recognition and diagnostic tools.

## Installation

Install `SaberShader_1_0_3_Blender_Addon.zip` through **Edit → Preferences → Add-ons → Install from Disk**. Do not unzip before installing. Disable the previous `sabershader_hf45746` package to avoid simultaneous registrations. Restart Blender and open **3D Viewport → N → SaberShader**.

The logo is bundled in `sabershader/assets/SaberShader_icon.png` and loaded as an optional Blender preview. No external logo path is required.

## Interface

- **Build SaberShader** detects the active character and builds the selected material setup; material and texture sources stay user-supplied.
- **General / MMD** provides common humanoid shading, multilingual material and texture filename recognition, optional manual role assignment, and texture/character tools.
- **Uma Musume** contains hair/body tuning, optional expression-eye overlays, texture checks and render matching.
- **FGO Arcade** contains source audits, material setup, facial/UV tools, reversible lighting, outline and scale controls.
- **Arknights: Endfield** provides source-gated Face SDF, hair, eye/iris, cloth, outline and LOD diagnostics.
- **Eye Tools, Texture Intelligence and Advanced** expose shared tools; they remain separate to avoid mixing profile-specific operations.

**General / MMD → Material & Texture Dictionary** provides exact source-name aliases (including imported English and CJK names). It also reports optional texture filename candidates, including `FC_1.jpg`, `face.png`, `Htn_MJ.png`, `MianJu_透.png`, and suffixes such as `_HN`, `_P`, `_ST`, `_RS`, `_C`, `_H`, `_S`. Filename hints are **not verified channel semantics** and cannot automatically rewire shaders. The role audit is read-only; applying a material role is opt-in and requires an unambiguous exact match.

## Optional artwork

The package does not include extracted game models, textures, animations or third-party expression-eye images. Optional expression PNGs can be loaded by the user into Blender or configured through the Uma Texture Library. Only use files you have permission to use.

## Package layout

```
sabershader/
    __init__.py           Blender metadata, class registration and lifecycle
    engine.py             Material construction, shader tools and diagnostics
    general_dictionary.py General / MMD aliases and texture filename hints
    ui.py                 Sidebar panels and logo preview management
    assets/
        SaberShader_icon.png
    README.md
    THIRD_PARTY_NOTICES.md
```

## Compatibility and scope

The user-facing add-on version is **1.0.3**. This package continues from the full working codebase and preserves existing Blender operator IDs, scene properties, node names and material metadata. Some historical numbers remain **only in internal persistent identifiers** to keep previously prepared `.blend` projects readable.

This revision improves documentation, user-visible labels, private helper names and General / MMD recognition. It does not redesign the shader solvers, replace texture sources, or alter game resources. Source names and texture suffixes are treated as clues, not verified evidence of texture channels.

The package passes Python syntax and archive checks. Full functional verification still requires Blender 5.1.1, especially material builds in each profile and an existing project migration test.

SaberShader is an independent community tool, not officially affiliated with the publishers of the supported games.

Repository: https://github.com/XDZR8/SaberShader
