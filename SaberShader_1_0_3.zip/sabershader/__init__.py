"""SaberShader Blender add-on registration and lifecycle."""

bl_info = {
    "name": "SaberShader 1.0.3",
    "author": "XDZR8",
    "version": (1, 0, 3),
    "blender": (5, 1, 1),
    "location": "View3D > Sidebar (N) > SaberShader",
    "description": "Profile-based stylized shaders for General/MMD, Uma Musume, FGO Arcade and Endfield.",
    "category": "Material",
}

import bpy
from . import engine as _engine
from . import ui as _ui
from .engine import (
    AEF_SaberShader_V8_Settings,
    AEF_PG_fgo_face_v4574,
    AEF_PG_fgo_opacity_research_v45744,
    AEF_PG_fgo_uv_research_v45745,
    AEF_PG_fgo_uv_repair_v45747,
    AEF_PG_fgo_shading_v45749,
    AEF_PG_fgo_live_v457410,
    AEF_PG_fgo_surface_research_v45746,
    _face_light_on_depsgraph_update,
    _face_light_on_frame_change,
    _face_light_update_dynamic,
    _sabershader_v1136_apply_eyehideall_bindings,
    _aef105a1_quarantine_lineart,
    XDZR8_V112_ROLE_ITEMS,
    log,
)

# Register classes in dependency order. Blender stores the operator and RNA
# identifiers in .blend files, so their legacy names must remain stable until
# a migration handles every existing scene and material reference.
_CLASS_ORDER = (
    'AEF_SaberShader_V8_Settings',
    'AEF_OT_add_shaders_v11',
    'AEF_OT_ae113_fidelity_uv_audit',
    'AEF_OT_ae110_refresh_outline',
    'AEF_OT_ae110_remove_outline',
    'AEF_OT_ae118polish_create_lights',
    'AEF_OT_ae118polish_remove_lights',
    'AEF_OT_ae120_inspect',
    'AEF_OT_ae120_guard',
    'AEF_OT_ae120_restore_guard',
    'AEF_OT_ae120_apply_overlay',
    'AEF_OT_ae120_restore_overlay',
    'AEF_OT_ae120_limit_iris',
    'AEF_OT_ae120_restore_iris',
    'AEF_OT_ae123_apply_preset',
    'AEF_OT_ae123_restore_preset',
    'AEF_OT_ae126_apply_color_management',
    'AEF_OT_ae126_restore_color_management',
    'AEF_OT_ae126_color_audit',
    'AEF_OT_ae129_apply_preset',
    'AEF_OT_ae129_restore_preset',
    'AEF_OT_ae129hf1_source_audit',
    'AEF_OT_ae129hf42_apply_preset',
    'AEF_OT_ae129hf42_restore_preset',
    'AEF_OT_ae129hf43_source_audit',
    'AEF_OT_ae129hf45_apply_preset',
    'AEF_OT_ae129hf45_restore_preset',
    'AEF_OT_ae129hf451_use_selected_light',
    'AEF_OT_ae129hf451_restore_final_views',
    'AEF_OT_ae129hf452_enable_scene_face',
    'AEF_OT_ae129hf452_setup_scene',
    'AEF_OT_ae129hf453_apply_hybrid',
    'AEF_OT_ae129hf453_outline_audit',
    'AEF_OT_ae129hf454_apply_balanced_face',
    'AEF_OT_ae129hf454_recover_hf2_normals',
    'AEF_OT_ae129hf455_apply_full_setup',
    'AEF_OT_ae129hf455gn_preview',
    'AEF_OT_ae129hf455gn_restore',
    'AEF_OT_ae129hf455gn_audit',
    'AEF_OT_ae129hf456_apply_hair_preset',
    'AEF_OT_ae129hf456_restore_hair',
    'AEF_OT_ae129hf456_preview_existing',
    'AEF_OT_ae129hf456_restore_existing',
    'AEF_OT_ae129hf456_hair_audit',
    'AEF_OT_ae129hf4565_lod_audit',
    'AEF_OT_ae129hf4565_select_lod',
    'AEF_OT_ae129hf4565_restore_lods',
    'AEF_OT_ae129hf4565_compress_preview',
    'AEF_OT_ae129hf45651_calibrate',
    'AEF_OT_ae129hf45651_restore_calibration',
    'AEF_OT_ae127_apply_eye_preset',
    'AEF_OT_ae127_restore_eye_preset',
    'AEF_OT_ae123_apply_eye',
    'AEF_OT_ae123_restore_eye',
    'AEF_OT_ae122_inspect',
    'AEF_OT_ae122_apply',
    'AEF_OT_ae122_restore',
    'AEF_OT_ae119_preview_eyeshadow',
    'AEF_OT_ae119_apply_eyeshadow',
    'AEF_OT_ae119_restore_eyeshadow',
    'AEF_OT_ae111_preview_cleanup',
    'AEF_OT_ae111_hide_cleanup',
    'AEF_OT_ae111_restore_cleanup',
    'AEF_OT_ae111_delete_cleanup',
    'AEF_OT_fgo_arcade_source_audit_v4572',
    'AEF_OT_fgo_arcade_resource_audit_v4573',
    'AEF_OT_fgo_arcade_relink_v4573',
    'AEF_OT_fgo_arcade_restore_images_v4573',
    'AEF_OT_fgo_arcade_store_native_map_v4573',
    'AEF_OT_fgo_arcade_restore_native_map_v4573',
    'AEF_PG_fgo_face_v4574',
    'AEF_OT_fgo_face_audit_v4574',
    'AEF_OT_fgo_face_convert_v4574',
    'AEF_OT_fgo_face_expression_v4574',
    'AEF_OT_fgo_face_reset_v4574',
    'AEF_OT_fgo_face_restore_v4574',
    'AEF_OT_fgo_face_overlay_audit_v45742',
    'AEF_OT_fgo_face_clean_neutral_v45742',
    'AEF_OT_fgo_face_restore_overlay_v45742',
    'AEF_OT_fgo_neutral_face_audit_v45743',
    'AEF_OT_fgo_neutral_face_preview_v45743',
    'AEF_OT_fgo_neutral_face_restore_v45743',
    'AEF_PG_fgo_uv_research_v45745',
    'AEF_PG_fgo_uv_repair_v45747',
    'AEF_OT_fgo_uv_orientation_audit_v45747',
    'AEF_OT_fgo_uv_orientation_preview_v45747',
    'AEF_OT_fgo_uv_orientation_apply_v45747',
    'AEF_OT_fgo_uv_orientation_restore_v45747',
    'AEF_PG_fgo_shading_v45749',
    'AEF_PG_fgo_live_v457410',
    'AEF_OT_fgo410_audit',
    'AEF_OT_fgo410_scale',
    'AEF_OT_fgo410_restore_scale',
    'AEF_OT_fgo410_outline',
    'AEF_OT_fgo410_restore_outline',
    'AEF_OT_fgo410_studio_lights',
    'AEF_OT_fgo410_restore_lights',
    'AEF_OT_fgo410_refresh_lighting',
    'AEF_OT_fgo_shading_audit_v45749',
    'AEF_OT_fgo_shading_preview_v45749',
    'AEF_OT_fgo_shading_restore_v45749',
    'AEF_PG_fgo_surface_research_v45746',
    'AEF_OT_fgo_surface_layer_audit_v45746',
    'AEF_OT_fgo_surface_layer_preview_v45746',
    'AEF_OT_fgo_surface_layer_restore_v45746',
    'AEF_OT_fgo_facial_uv_audit_v45745',
    'AEF_OT_fgo_facial_uv_preview_v45745',
    'AEF_OT_fgo_facial_uv_restore_v45745',
    'AEF_PG_fgo_opacity_research_v45744',
    'AEF_OT_fgo_native_opacity_audit_v45744',
    'AEF_OT_fgo_native_opacity_probe_v45744',
    'AEF_OT_fgo_native_opacity_restore_v45744',
    'AEF_OT_mmd_umd_custom_template',
    'AEF_OT_mmd_umd_scan',
    'AEF_OT_mmd_umd_apply_roles',
    'AEF_OT_mmd_umd_restore_roles',
    'AEF_OT_mmd_umd_apply_preset',
    'AEF_OT_mmd_umd_restore_preset',
    'AEF_OT_sabershader_build_v8',
    'AEF_OT_outline_pipeline_audit_v109b31',
    'AEF_OT_uma_texture_library_audit_v11932',
    'AEF_OT_uma_texture_library_open_report_v11932',
    'AEF_OT_uma_hair_render_match_v1148',
    'AEF_OT_uma_hair_render_match_restore_v1148',
    'AEF_OT_sabershader_save_copy_v8',
    'AEF_PT_saber_shader_v8',
    'AEF_PT_ui121_character',
    'AEF_PT_ui121_general_eyes',
    'AEF_PT_ui121_endfield',
    'AEF_PT_ui121_ae_core',
    'AEF_PT_ui121_ae_face_hair',
    'AEF_PT_ui121_ae_hair_fidelity',
    'AEF_PT_ui121_ae_hair_compression',
    'AEF_PT_ui121_ae_lod_selector',
    'AEF_PT_ui121_ae_cloth_eye',
    'AEF_PT_ui121_ae_eye_repair',
    'AEF_PT_ui121_ae_outline_cleanup',
    'AEF_PT_ui121_ae_gn_outline',
    'AEF_PT_ui121_ae_audit',
    'AEF_PT_ui121_uma',
    'AEF_PT_ui121_fgo_arcade',
    'AEF_PT_ui121_fgo_arcade_face_v4574',
    'AEF_PT_ui121_fgo_face_overlay_v45742',
    'AEF_PT_ui121_fgo_neutral_face_v45743',
    'AEF_PT_ui121_fgo_native_opacity_v45744',
    'AEF_PT_ui121_fgo_facial_uv_v45745',
    'AEF_PT_ui121_fgo_uv_orientation_v45747',
    'AEF_PT_ui121_fgo_shading_v45749',
    'AEF_PT_ui121_fgo_live_v457410',
    'AEF_PT_ui121_fgo_surface_layers_v45746',
    'AEF_PT_ui121_textures',
    'AEF_PT_ui121_advanced',
    'AEF_PT_ui121_mmd_dictionary',
)


def _resolve_class(name):
    return getattr(_ui, name) if hasattr(_ui, name) else getattr(_engine, name)


classes = tuple(_resolve_class(name) for name in _CLASS_ORDER)

def register():
    _ui.register_brand_icon()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.aef_sabershader_v8 = bpy.props.PointerProperty(
        type=AEF_SaberShader_V8_Settings
    )
    bpy.types.Scene.aef_fgo_face_v4574 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_face_v4574
    )
    bpy.types.Scene.aef_fgo_opacity_research_v45744 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_opacity_research_v45744
    )
    bpy.types.Scene.aef_fgo_uv_research_v45745 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_uv_research_v45745
    )
    bpy.types.Scene.aef_fgo_uv_repair_v45747 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_uv_repair_v45747
    )
    bpy.types.Scene.aef_fgo_shading_v45749 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_shading_v45749
    )
    bpy.types.Scene.aef_fgo_live_v457410 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_live_v457410
    )
    bpy.types.Scene.aef_fgo_surface_research_v45746 = bpy.props.PointerProperty(
        type=AEF_PG_fgo_surface_research_v45746
    )
    bpy.types.Scene.hf45743_face_original_mix = bpy.props.FloatProperty(
        name='Original Atlas Detail',
        description='Fraction of the original S01 face atlas to mix with the neutral preview (diagnostic only)',
        min=0.0, max=0.40, default=0.08, precision=3,
    )
    bpy.types.Scene.hf45743_face_skin_color = bpy.props.FloatVectorProperty(
        name='Neutral Skin',
        description='Preview skin color; calibrated for the reviewed S02 character, manually adjustable for others',
        size=3, subtype='COLOR', min=0.0, max=1.0, default=(0.95, 0.79, 0.69),
    )
    if _face_light_on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_face_light_on_depsgraph_update)
    if _face_light_on_frame_change not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(_face_light_on_frame_change)
    try:
        _face_light_update_dynamic(bpy.context.scene)
    except Exception as exc:
        log(f'Face lighting initialization warning: {exc}')
    try:
        _sabershader_v1136_apply_eyehideall_bindings(bpy.context.scene, force_detect=False)
    except Exception as exc:
        log(f'Expression eye visibility sync warning: {exc}')

    bpy.types.Material.xdzr8_role_override = bpy.props.EnumProperty(
        name='XDZR8 Material Role Override',
        description='Optional manual role for the active material. Auto Detect keeps the guarded classifier, usage specialization, and audit in control',
        items=XDZR8_V112_ROLE_ITEMS,
        default='AUTO',
    )

                                                                            
                                                                           
                                                                              
                                                                            
    try:
        _aef105a1_quarantine_lineart('addon register / emergency guard')
    except Exception as exc:
                                                                                 
        log(f"Line Art compatibility check warning: {exc}")

def unregister():
    _ui.unregister_brand_icon()
    try:
        while _face_light_on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(_face_light_on_depsgraph_update)
    except Exception:
        pass
    try:
        while _face_light_on_frame_change in bpy.app.handlers.frame_change_post:
            bpy.app.handlers.frame_change_post.remove(_face_light_on_frame_change)
    except Exception:
        pass
    if hasattr(bpy.types.Material, 'xdzr8_role_override'):
        del bpy.types.Material.xdzr8_role_override
    if hasattr(bpy.types.Scene, 'hf45743_face_skin_color'):
        del bpy.types.Scene.hf45743_face_skin_color
    if hasattr(bpy.types.Scene, 'hf45743_face_original_mix'):
        del bpy.types.Scene.hf45743_face_original_mix
    if hasattr(bpy.types.Scene, 'aef_fgo_live_v457410'):
        del bpy.types.Scene.aef_fgo_live_v457410
    if hasattr(bpy.types.Scene, 'aef_fgo_shading_v45749'):
        del bpy.types.Scene.aef_fgo_shading_v45749
    if hasattr(bpy.types.Scene, 'aef_fgo_uv_repair_v45747'):
        del bpy.types.Scene.aef_fgo_uv_repair_v45747
    if hasattr(bpy.types.Scene, 'aef_fgo_surface_research_v45746'):
        del bpy.types.Scene.aef_fgo_surface_research_v45746
    if hasattr(bpy.types.Scene, 'aef_fgo_uv_research_v45745'):
        del bpy.types.Scene.aef_fgo_uv_research_v45745
    if hasattr(bpy.types.Scene, 'aef_fgo_opacity_research_v45744'):
        del bpy.types.Scene.aef_fgo_opacity_research_v45744
    if hasattr(bpy.types.Scene, "aef_fgo_face_v4574"):
        del bpy.types.Scene.aef_fgo_face_v4574
    if hasattr(bpy.types.Scene, "aef_sabershader_v8"):
        del bpy.types.Scene.aef_sabershader_v8
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
