# SaberShader developer notes

## Responsibilities

| Module | Purpose | Important invariant |
| --- | --- | --- |
| `__init__.py` | Add-on metadata, registration and module compatibility checks | Keep registered RNA/operator identifiers and module signatures stable |
| `ui.py` | Sidebar presentation, status and optional controls | Do not call shader-building operators from `draw()`; hide debug UI without disabling Build |
| `ae_ui_visibility.py` | Developer-panel visibility policy | Preferences only; no .blend data mutation |
| `engine.py` | Core materials, source evidence, eye masks, outline and all profile operators | Preserve legacy scene IDs, nodes, source checks and restoration snapshots |
| `ae_one_click.py` | Main Build orchestration | Run the core Build once; add AE stages only for verified AE sources |
| `ae_full_visual_e3452.py` | Post-build status and scene view transform | Report observed counts, not assumed success; verify scene owner |
| `ae_eye_build_e3454.py` | Source-aware LOD0 eye-shadow validation/recovery | Use actual valid UV layer; never guess missing/ambiguous UV; do not duplicate valid masks |
| `ae_si_build_a_e3451.py` | Si-only verified VFX appearance and Repeat Build | Preserve the original slots, exact seven-mesh scope and restoration data |

## Naming convention

Use **meaningful names** for UI labels, buttons, error messages and hover
tooltips: "Hair Rim Light", "Eye Shadow Repair", "FX Comparison". Revision
suffixes such as `v45747`, `AE123`, `E3455`, and `HF4.5.3` belong in historical
internal code and troubleshooting documentation only.

Do **not** rename `bl_idname`, `PropertyGroup` attribute names, scene keys,
material custom properties, RNA properties or stored enums as part of visual
cleanup: existing Blender files and external scripts may reference them.

## Build and failure behavior

- Source verification must precede Endfield-specific mutations. A name resembling
  an Endfield mesh is not sufficient proof.
- Public Build must continue without requiring the developer UI to be visible.
- Manual A/B sessions and JSON exports must not run implicitly.
- Post-build eye checks must use actual LOD0 materials and available original
  masks; a result of `MISSING_UV0` from older versions may mean a nonstandard
  UV-layer name, not necessarily an untextured mesh.
- An unsuccessful optional stage should report exactly what was skipped and why.
- Repeat Build should preserve verified authoring and restoration state, not
  stack duplicate material graphs.

## Regression check

Confirm add-on registration/unregistration, module signature validation,
public/developer UI toggle, Si/other-AE/non-AE Build routing, eye-shadow
recovery, outline/color behavior, restore paths and repeat-build idempotency.

**Offline tests validate code structure only.** Final visual confirmation must
be done inside Blender with valid source FBX/PNG/JSON and a copy of the .blend.
