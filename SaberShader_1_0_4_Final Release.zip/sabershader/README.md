
> **Endfield interface:** the sidebar focuses on Build feedback and optional
> artist actions. Automatic visual stages, research tools and JSON reports are
> hidden by default. Developers can re-enable them under **Blender Preferences
> > Add-ons > SaberShader > Show AE Developer Tools**. Public labels use
> descriptive feature names rather than internal revision codes.
> See `README_E3457_NAMING_CLEANUP.md` for the naming policy.

# SaberShader 1.0.4

SaberShader is an independent Blender add-on for stylized character shading,
material and texture recognition, and scene diagnostics. Its supported profiles
include **General / MMD**, **Uma Musume**, **FGO Arcade**, and **Arknights: Endfield**.
It works with user-supplied models and source textures; it does not provide them.

## Installation and safe updating

1. In Blender, use **Edit → Preferences → Add-ons → Install from Disk** and select the SaberShader ZIP.
2. Enable **SaberShader** and open **3D Viewport → Sidebar (N) → SaberShader**.
3. For updates, **disable the old add-on, fully close Blender, replace the installed package, and restart Blender**. Do not keep multiple active copies of the `sabershader` package.
4. Always back up the original `.blend`. Test changes and upgrades on separate copies.

The bundled icon is located at `sabershader/assets/SaberShader_icon.png`.

## Interface and profiles

- **Build SaberShader:** prepares the selected character's material setup from available sources. Confirm the active character and inspect detected materials and textures before building.
- **01 General / MMD:** general stylized shading, material roles, multilingual source-name recognition, texture filename hints, optional manual role assignment and common character tools.
- **02 Eye Tools:** shared eye inspection and repair controls; use the relevant profile-specific tools where applicable.
- **Uma Musume:** anime hair and body shading controls, expression-eye overlays, texture diagnostics and render-matching tools (including **UMA Hair Lab**).
- **FGO Arcade:** source audits, facial materials, UV checks and repairs, lighting, outline and scale controls.
- **Arknights: Endfield:** one-click visual Build with source-verified shading, eye-shadow recovery, outline and color adjustments. The regular panel shows the last Build status, optional LOD selection and preview lighting; technical stage controls appear only in Developer Tools.
- **05 Texture Intelligence:** shared texture analysis tools and source inspections.
- **06 Advanced & General:** additional diagnostics and general utilities.

The exact controls shown depend on the selected profile, context and supported model data. Some sections are collapsed within a profile panel instead of appearing as separate Blender tabs.

### Material & Texture Dictionary (General / MMD)

Open **General / MMD → Material & Texture Dictionary** to inspect source-name
aliases and possible texture roles. The dictionary supports exact source-name
matches (including imported English and CJK labels), plus optional filename
hints such as `FC_1.jpg`, `face.png`, `Htn_MJ.png`, `MianJu_透.png` and suffixes
like `_HN`, `_P`, `_ST`, `_RS`, `_C`, `_H`, `_S`.

**A filename or suffix is a hint, not proof of a texture channel's meaning.**
Do not assume an unknown imported texture is a normal, mask, roughness or color
map solely from its name, and do not automatically rewire shader inputs on that
basis. The role audit is read-only; applying a role is an explicit operation
that requires an unambiguous source match.

## Si VFX Idle Ink A/B E3.4.1 — optional AE study

In **Arknights: Endfield → AE Source Material Dictionary (Si)**, use **Prepare
A/B from Current Si**, then **Show A** or **Show B**, **Record A/B Metadata
(Read Only)**, and **Restore Original (A/B)**. This remains a **manual
experiment** for seven exact Si `vfxpart_lod0` objects; the standard Build
**does not create a manual A/B session**. Since E3.4.5.1, the *single A look*
can be applied automatically as the normal verified Si Build output, tracked
separately from the E3.4.1 study. A captures an existing qualifying Mask material exactly
or otherwise uses a labeled single-trail approximation; B preserves the E3.3.2
Dual Layer construction except for swapping which texture is Main vs Detail.

To safeguard **active manual E3.4.1 A/B or E3.4.4 A/A2 comparisons**, **Build
remains blocked until their Restore Original is used**. Auto-Build A, unlike
those research sessions, can be safely suspended and reused during Repeat Build.
See `README_E3451_SI_BUILD_A.md`. Use a copy of the `.blend`, confirm all seven meshes share the source
material, and keep the texture folder configured. Save identical-camera A/B
screenshots and metadata JSON. The experimental variants are not official game
shader reproductions, and Blender-native save/reload and rendering are pending.

## Arknights: Endfield EyeShadow post-Build guarantee (E3.4.5.3)

The main **Build SaberShader** now verifies the exact LOD0 eye-shadow mask after the existing AE material Build and attempts an AE123 source-authenticated repair only when the overlay is absent/invalid. `PARTIAL` identifies missing source JSON/PNG, UV0, actor/LOD0 ambiguity or other blockers instead of showing a false success; **no white-opaque fallback is manufactured**. The original eye material and manual ownership remain reversible and protected. See `README_E3453_EYESHADOW_AUTO_BUILD.md`; restart Blender entirely after upgrading to clear stale modules.

## Arknights: Endfield complete visual Build (E3.4.5.2)

The top **Build SaberShader** now executes **one guarded AE material Build** with the supported visual stages enabled for any currently source-verified single Endfield actor. On existing `.blend` projects, an explicitly disabled final-stage toggle may be promoted to ON when **Complete AE Visual Build (automatic)** is enabled (default). The original numeric tuning, UV maps and custom artistic calibration are not reset. To retain manual per-stage OFF choices, disable this master option before building. `SOURCE` fidelity preset excludes additional grading.

The Build handles source ramps, hair, cloth, eyes, scene-responsive face (SCENE), final hair views, exact Wulfa HF2 normals, rim, highlight compression, graded material nodes, **AE inverted-hull outline**, **AE123 authenticated eyeshadow LOD0 overlay**, reversible helper cleanup, and the **AE126 Khronos PBR Neutral** scene View (saved for later **Restore View**). Actual result status is visible in Endfield tools as **Outline / Eyeshadow / Color**; missing source data produces an explicit skipped/partial status, not a fake success. Shader source maps and color-space assignments on original images are preserved.

Manual **A/B research and previews**, experimental face SDF target/channel selection, the 3-point scene light rig, arbitrary LOD switching, Restore/Delete operators and diagnostic audits **do not run** as part of the automatic visual workflow. The original Si **Single Trail A** auto-Build from E3.4.5.1 is retained only for verified Si. For non-AE profiles the original Build path is unchanged. See `README_E3452_COMPLETE_AE_VISUAL_BUILD.md` for scope, how to validate and unresolved native tests.

## AE Si VFX B: integrated Build validation (E3.3.2.1)

For Si (`jsspsi`) in a **verified Endfield** profile, the ONE-CLICK Build retains
the existing E3, E3.1, E3.2 and E3.3.2 FX stages and then runs a small native
structural check for the seven VFX parts. **The dual-layer shader look is
unchanged** by this update.

In **Arknights: Endfield → AE Source Material Dictionary (Si)**,
**Inspect Si FX Materials (Read Only)** exports a detailed JSON report. Selecting
the Si armature is recommended so all seven parts are in scope. The report
contains assigned materials, historical markers, predecessors, users, image
node IDs and graph hashes.

Build stores a small QA fingerprint as Scene metadata only after finding all
seven expected VFX_B assignments. Run Build a second time on the same Si scene
to check that the assigned VFX_B materials and their graph have not changed.
To test persistence, **save the built .blend, close Blender, reopen the saved
file in a new Blender session, select Si and run the Read Only validation**.
The report then checks the stored fingerprint. This is structural data
persistence, not a render-fidelity certification.

The read-only diagnostics do **not** run a second Build, Restore, texture-failure
injection, scene save/reopen or other-profile Build automatically. Those require
explicit testing on a copy of the scene. Non-Si material comparison covers
only the optional Si FX stages after the legacy AE Build. An initial Build
**cannot** by itself prove idempotence or cross-session persistence.

## Recommended workflow

1. Open a **copy** of the scene and select the intended character.
2. Confirm the profile and review the detected objects, materials and source textures.
3. If appropriate, run **Build SaberShader** and inspect the resulting materials.
4. Check facial shading, hair, eyes, outlines, lighting and render color using the relevant profile controls.
5. Save a new `.blend` copy when you need to keep the result; keep the source scene available for comparison.

## Safety and session tools

- **Line Art Diagnostics:** inventories potentially unsafe Grease Pencil Line Art modifiers and can export a JSON report upon request. The inspection does not delete modifiers. The reference build may refuse to continue if it detects a known Line Art risk.
- **Live Sync & Session:** dynamic updates are **off when the add-on starts**. Enabling Live Sync may write shader properties and shape-key values as the scene changes; disabling it does not undo earlier changes.
- **Rescan EyeHideAll:** refreshes the EyeHideAll bindings after importing a character or editing related shape keys. This is an explicit operation that can set shape-key values and supports Undo.
- **JSON export:** reports are not overwritten. On filesystems without hard-link support, the exclusive-copy fallback is **not atomic**, so another process might briefly observe an incomplete destination while it is being copied.

**Important Line Art limitation:** the native Blender Line Art evaluator may still
crash before any Python safety check has a chance to run. The preflight reduces
exposure in supported operations; it **cannot guarantee crash prevention**.
Always work on saved copies and keep an untouched original `.blend`.
See `SAFETY_NOTES.md` for details.

## Optional artwork and rights

**SaberShader is an independent community tool and is not officially affiliated
with, endorsed by or sponsored by the publishers or rights holders** of the
supported games and characters.

**This package does not include extracted game models, textures, animations or
third-party expression-eye artwork.** Optional images and other assets must be
supplied by the user. **Only use files you own or have permission to use.**
Game names, character names and trademarks remain the property of their
respective owners; supporting a profile does not grant rights to third-party
resources. See `THIRD_PARTY_NOTICES.md`.

Repository: https://github.com/XDZR8/SaberShader

## Package layout

```text
sabershader/
  __init__.py           # Add-on metadata and registration
  engine.py             # Shader profiles, material tools and diagnostics
  ui.py                 # Sidebar interface and icon preview
  general_dictionary.py # General/MMD source aliases and filename hints
  handler_dispatch.py   # Live Sync filtering and diagnostic counters
  lifecycle_core.py     # Transactional registration and rollback
  lifecycle_state.py    # Session state
  lifecycle_controls.py # Live Sync controls
  lineart_safety.py     # Line Art risk inspection
  lineart_tools.py      # Line Art diagnostic operators and JSON export
  assets/
    SaberShader_icon.png
  README.md
  RELEASE_NOTES.md
  SAFETY_NOTES.md
  THIRD_PARTY_NOTICES.md
```

## Compatibility and validation

The **public version is 1.0.4**. Some historical numbers remain in operator IDs,
classes, scene/material properties, generated node names and metadata because
they are **compatibility identifiers stored in existing `.blend` projects**.
They do not represent the current version and must not be renamed casually.

This package includes experimental Si FX modules; the E3.3.1 look pass changes preview shaders after a verified AE Build.
SaberShader has passed static checks; full functional and visual compatibility
for every profile still requires tests in Blender on real project copies.
For details, see `RELEASE_NOTES.md`.

## Arknights: Endfield — Source Material Dictionary: Si (E1 research)

The **AE Source Material Dictionary (Si E1)** subpanel provides a **read-only**
material/texture connection audit, based on the user-provided `Si - Default`
Unity material JSON and PNG files. The bundled dictionary contains 25 exact
JSON materials, 61 declared PNG assets, verified slot names and limited
source color/float metadata. **No game assets, textures, or FBX are bundled.**

To audit a copy of Si's existing `.blend`, open **N → SaberShader → Arknights:
Endfield → AE Source Material Dictionary (Si E1)** and select **Audit Si Sources
(Read Only)**. The resulting JSON report is written to a new temporary file;
the exact path is printed to Blender's system console. The inspector only
examines scene meshes with `jsspsi`-identifying names/materials and never
changes shader nodes, materials or textures.

Unity `M_fx_*` shader formulas, alpha compositing, UV animation and packed
channel semantics have **not** been reconstructed. In particular, `_MainTex`
on an FX material is **not** treated as an interchangeable `_BaseMap`.
Neither a white viewport object nor an image filename alone proves the cause
of the white material. Use the report to identify exact affected objects,
source materials and missing Blender connections before building new FX shaders.
This E1 extension is not a final visual fix for Si's VFX.

## Arknights: Endfield — Unified One-Click Build (E2 candidate)

**One main button:** `Build SaberShader`. For a currently source-verified
Endfield character, the button delegates to the existing guarded AE Full Setup
operation, which performs **one** legacy shader Build. Existing Build stages
include verified source/material discovery, guarded default settings (only on
first verified AE Build), face/hair/cloth shading, eyes, ink/outline, supported
final hair compression and built-in audits. Existing scene customizations are
preserved on later builds; this button does not force reapply settings.

**Automatic post-Build source audit for Si**: after successful AE Build,
SaberShader checks the exact Si catalog and writes a fresh JSON under the OS
temporary folder. A compact status and the path are reported in Blender, with
summary stored as scene metadata. Other AE models are not incorrectly treated
as Si. Manual re-audit remains available in the collapsed dictionary panel.
For scenes with an unverified AE source, the legacy Build may first recover
textures and perform its own profile verification; an actor name alone never
confers AE authorization. General/MMD, FGO and Uma follow their original Build.

**Intentional exclusions:** manual previews, experimental geometry-node
outlines, permanent helper deletion, source material rewriting, scene light
creation/movement and arbitrary color-management changes are **not** executed
implicitly. They can modify the user's art decisions or lack verified source
semantics. Those options remain available separately if desired. A single Build
is not a promise of render equivalence to Unity.

Si's 2026-11-20 E1 audit: 43 mesh/material slots, 10 base textures connected,
5 FX material image sets incomplete, 1 unverified procedural FX, 7
`DefaultHGMaterial` surfaces lacking a source BaseMap, and 20 generated
SaberShader expression-eye / outline helper slots (now distinguished from
unknown original materials). All the image nodes that the E1 report actually
listed were accessible. None of those findings alone proves the pixel-level
reason for bright white effects. **The new Build does not invent Unity FX
shader equations**. Reconstruction of FX masks, UV flow, blend modes and
transparency still requires a separate visually validated implementation.

**QA boundary:** E2 offline tests use mocked Blender APIs. On Blender 5.1.1,
run the first Build only on a duplicate `.blend`; verify `Last Run` telemetry,
Eye/Face/Hair/Outline appearance, and the new Si JSON before publishing or
replacing a known-good shader configuration.


## Arknights: Endfield — Si FX Reconstruction E3 (experimental)

For a verified Si actor, the **single main Build SaberShader** now attempts an
experimental *ink stroke preview* for five exact Unity FX source materials
(`cloth_04`, `05`, `06`, `08`, `09`). Each material is duplicated, preserving the
pre-E3 material in the Blender file with a fake user; the original material is
not rewritten. Rebuilding Si or returning to the E2 material is possible using
**Restore Si FX (Advanced)** in the Si Source Material Dictionary subpanel.

The E3 nodes connect existing source `_MainTex`, `_MaskTex`, `_DisturbTex1` and
optional `_BlendTex` with their JSON UV transforms, a low static distortion,
transparent/Emission mixing and adjustable preview opacity. **This is not a
faithful port of the Unity FX shader.** No time-varying distortion, native
particle/vertex color, channel semantics or real-game color grade is claimed.
Seven `DefaultHGMaterial` `vfxpart` meshes and procedural `cloth_07` remain
unchanged; do not hide them as a blanket workaround. Missing images cause a
per-material skip with a warning, rather than random file matching.

The source audit is still read-only, and runs after E3 Build; a connected map
status does not prove visual accuracy. Always compare rendered frames in a
backup scene with actual game footage. E3 is validated only with offline
Python/Blender mocks, not a native Blender 5.1.1 render.

## Arknights: Endfield — Si FX Opacity & VFX Classification E3.1 (experimental)

The same **Build SaberShader** button, on a **verified Si AE** source only,
retains E3's reconstruction of five exact FX materials and performs an
additional E3.1 preview calibration. The *E3* shader graph, source maps, and
original material restore mechanism remain intact. E3.1 multiplies each
previous E3 preview opacity by **0.25** (examples: 0.262745 → 0.065686,
0.12 → 0.0300, 1.0 → 0.25); this is an **experimental visual hypothesis**,
not a verified game-accurate alpha value. It is not applied to custom opacity
settings, active A/B tests, linked materials, or materials shared outside
selected Si objects. Repeated Build does not repeatedly reduce opacity.

For comparison, the **AE Source Material Dictionary (Si)** advanced panel
contains *Restore E3 FX Opacity (Advanced)*: it restores the five original E3
preview factors when E3.1 had changed them. *Restore Si FX (Advanced)* still
restores the actual pre-E3 material datablocks (original E3 marker retained).

The seven exact `S_actor_jsspsi_vfxpart_01..07_lod0` objects with original
`DefaultHGMaterial` are now categorized as **VFX_PLACEHOLDER_UNVERIFIED** in
the source audit, rather than generic untextured materials. This classification
is read-only; their already-assigned opaque `SaberShader - Hair` shader is
**not** replaced in E3.1 because source materials and game-state visibility
are not established. No automatic hiding, mesh deletion, or UV animation.
This means **some white parts may remain**, pending in-game validation and a
separate VFX treatment. Generated SaberShader eye/outline helpers remain
classified separately and are never treated as missing source materials.

Save a copy of the `.blend` before testing. Compare Material Preview and a
real render, preferably with the five FX temporarily isolated from the seven
vfxpart. E3.1 tests are offline Python mocks, not a native Blender 5.1.1
render or Unity shader equivalence certification.


## Arknights: Endfield — Si VFX Dual Layer + Distortion E3.3.2 (experimental)

The ONE main **Build SaberShader** operator now runs a Version B preview
for the seven exact `S_actor_jsspsi_vfxpart_01..07_lod0` meshes after a
**verified Arknights: Endfield Build for Si**. It inherits the same
profile gate and scope as E3/E3.1/E3.2/E3.3.1. It does not run on other
AE actors, FGO, Uma or General profiles, or on unidentified materials.

Version B replaces the procedural Noise+Wave VFX appearance with sourced
textures: main `T_fx_trail_fj_09_1_v1d4_M.png`, detail
`T_fx_trail_gfx_18.png` (alternative `T_fx_noise_cyt_003_1.png`),
distortion `T_fx_normal_501_N.png` (alternative `T_fx_flow_527_M.png`),
and optionally the global mask `T_fx_jsspsi_si_mask5_M.png`. The user must
provide the images separately in Blender's image datablocks or in the
configured source texture folder (extracted from the user's Si package).
No game textures are bundled with this addon.

The default preview uses Non-Color local image copies where needed, dual
UV mappings, a low-strength static distortion, two contrast ramps, detail
mix factor 0.40, Facing modulation, emission 0.55 and maximum alpha 0.23.
**Automatic UV scroll is OFF** to avoid introducing drivers; Mapping
Location can be adjusted or keyed manually. This is **not** a verified
recreation of Unity's materials or time/particle VFX.

### Existing `.blend` files and restoration

An untouched procedural E3.3.1 VFX material is recognized and migrated to
Version B by clicking the SAME Build button. A user-edited E3.3.1 VFX
material is preserved instead of overwritten. E3.3.1 ink FX materials
already built are not rebuilt. The B stage retains the E3.3.1 original
material as a separate datablock. **Restore Si FX Look (E3.3.x)** reverts
one stage at a time: when migrating an existing E3.3.1 VFX, the first
restore returns to E3.3.1, and another restore returns to E3.2. For a
new build the first restore returns to E3/E3.2.

Missing REQUIRED images or stage failures cancel this optional FX stage
and preserve its previous materials. They do **not** roll back or falsify
an otherwise successful main Build. Check the operator warning and set
`universal_texture_folder` to the extracted Si textures directory.
Use a copy of your `.blend` and restart Blender after installing.
Native Blender 5.1.1 preview/render validation is still pending.

## Arknights: Endfield — Si FX Look Matching E3.3.1 (experimental)

In a **verified Si AE build**, the single `Build SaberShader` action performs
the existing source workflow, E3/E3.1/E3.2 material preparation, and then
**E3.3.1 look matching**. The five E3 ink effects receive absolute *preview*
opacity/emission targets per source material. Targets do not multiply the
E3.1 result, so `cloth_05` is set to 0.05 alpha preview and 0.48 emission,
not an accumulated E3 × E3.1 × E3.3 factor. Manually altered E3 shader
values are skipped.

The seven exact `vfxpart` previews use a **ColorRamp → RGB to BW → alpha**
path with a soft facing modulation. The maximum preview alpha is 0.12,
not a constant 0.06, so the noise pattern genuinely affects coverage.
This procedural preview is static: no game-derived time/particle shader,
UV animation or verified Unity-equivalent appearance is claimed.

E3.3.1 **copies the active E3/E3.2 preview datablocks before changing nodes**.
All new material graphs are prepared before slot swaps, and failures trigger
an attempted rollback. Previous materials are kept by name with fake users.
In the *AE Source Material Dictionary (Si)* panel, use **Restore Si FX Look
E3.3.1** before any earlier E3/E3.1/E3.2 restore button. Older restoration
operations intentionally refuse to run while E3.3.1 is active.

If upgrading a saved scene on which **legacy E3.3** was already run,
E3.3.1 checks its stored baseline and only migrates unchanged FX values.
Custom opacity, emission, tint or blend adjustments are preserved; unfamiliar
materials are skipped. Restoring E3.3.1 in a legacy scene returns the exact
previous E3.3 material; it does not automatically undo the older E3.3 edit.
Use a pre-E3.3 scene copy to recover that older baseline when necessary.

As with all experimental source reconstructions, test on a duplicate `.blend`,
compare viewport and render against real game screenshots and keep the
untouched source. No native Blender validation was run for E3.3.1.
The bundled Si source dictionary contains metadata derived from user-supplied
game assets; see `THIRD_PARTY_NOTICES.md` before redistributing it.


### AE Si E3.3.2.2 — protección de VFX_B en Build repetido

Un segundo Build en E3.3.2.1 podía sustituir `VFX_B` por `SaberShader - Mask.002`.
E3.3.2.2 preserva el material dual-layer únicamente en los siete `vfxpart`
verificados y evita regenerar una máscara genérica para un material que solo
utilizan esas siete mallas. No modifica el aspecto del shader. Si la escena
ya había sufrido la sustitución, abrir una copia anterior al Build fallido;
esta protección no reconstruye automáticamente datablocks que ya se hayan
perdido. Reiniciar Blender después de actualizar el addon.


### E3.3.2.4 EyeShadow source layout

The AE EyeShadow LOD0 reconstruction reads `M_eyewhiteshadow_common_01.json`
from the actor's `Materials/` directory and the corresponding mask from
`Textures/`. Set Texture Folder to the actor root or its `Textures/` folder.
The general Hard-Bind audit counter is independent of EyeShadow overlay success;
consult `SaberShader_AE_HardBind_Audit` and the AE123/AE124 eye reports to
identify remaining unresolved entries. No automatic material guessing is used.


## E3.4.5 cross-character QA

E3.4.5 adds explicit per-actor A/A2, restore, repeat-Build and cross-actor evidence checks; it does **not** enable universal FX auto-apply. See [`README_E345_CROSS_CHARACTER.md`](README_E345_CROSS_CHARACTER.md).
