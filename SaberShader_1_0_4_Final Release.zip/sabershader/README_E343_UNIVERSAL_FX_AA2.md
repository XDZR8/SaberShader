# E3.4.3 — AE Universal FX A/A2 Fidelity Controls

**Purpose:** artist-controlled, reversible source-driven preview for *any* verified Arknights: Endfield actor with a supported, source-authored textured FX material. **A** is the exact pre-existing material datablock; **A2** is a private copy of its shader graph. No auto-Build adoption and no assumptions about operator identity, element (Cryo etc.) or image filenames.

## Where

`3D Viewport > Sidebar (N) > SaberShader > Arknights: Endfield > AE Universal FX A/A2 Fidelity E3.4.3`

## Requirements

- Verified AE Build for one actor; select one active **FX mesh** and the appropriate **active material slot**.
- Valid `AEF_V11_SourceMaterial` or exact original Unity name, plus matching `Materials/<source>.json` and `Textures/<_MainTex>.*` in the configured source sibling directories.
- The material must have exactly one **output-connected, top-level `_MainTex` image node**, an independent color path, and a single verifiable `Transparent BSDF + Mix Shader` transparency path. This is a deliberately conservative supported subset.
- Meshes and material must be local; affected meshes must be single-user. No mixed actor selections; no active E3.4.1 or E3.4.3 session on the same actor or material.
- `DefaultHGMaterial` placeholders, procedural FX, absent source files and unknown graph topologies **fail closed**. Si's seven `vfxpart` placeholders are **not** automatically treated as authored textured FX. Their confirmed Si-specific A baseline is retained in E3.4.1; the future E3.4.4 preset addresses that separate case.

## Workflow

1. **Save a copy** of your `.blend` after a valid AE Build. Close Blender before updating the addon, then reopen.
2. **Prepare A/A2 (No Visual Change)** creates a private A2 and records exact material IDs; A remains visible and node graph unchanged. For shared material usage *within the same actor*, all matching material slots are grouped; usage in other actors remains untouched.
3. **Show A** and **Show A2** switch only the recorded actor's material slots. Keep the same camera, exposure, viewport shading, frame, and illumination for visual comparison.
4. Set the parameters and press **Apply Controls to A2**. A is never touched. Neutral defaults should approximate A's existing graph; render-equivalence is not guaranteed.
5. **Record A/A2 Metadata** writes a JSON in the Windows temp directory; its path is printed in Blender's System Console. It includes graph topology fingerprints and parameters, **not** screenshots or native render measurements.
6. **Restore Original FX** reassigns the exact original material IDs and clears the experiment. Repeat Build **only after Restore**. No auto-selection or auto-material writes from E343 in Build.

## Universal controls

- `Alpha Power`: changes density distribution after the *existing* transparency calculation.
- `Alpha Multiplier`: global alpha factor, clamped 0–1 at output.
- `Edge Fade`: a cutoff/remap of low-alpha portions of the effect; this is an **alpha threshold**, not geometry/Fresnel edge detection.
- `Brightness`, `Contrast`, `Color Tint`: applied only to an unambiguous authored `_MainTex` RGB path that feeds rendered color and not alpha. No image or color-space modification.
- `Emission Gain`: multiplies top-level Emission node strength if present; otherwise logged as unsupported for that particular material (other controls still work).

A2 does **not** reconstruct native Unity FX particle equations, UV scrolling, blend order, distortion, vertex colors, or runtime animation. Existing authored graph topology is preserved as far as feasible; the mathematical controls may not be perceptually neutral on all Blender backends. Always judge captures in Blender.

## Safeguards

All actions require explicit user input; the source inventory E342 remains read-only. Two guarded Build entry points reject active E343 experiments: main `Build SaberShader` and `Build + Apply AE Full Setup`. The low-level legacy `aef.add_shaders_v11` operator called directly from Python or old addon versions may bypass these specific guards: **do not run it during a comparison**.

Restore is intentionally fail-closed if target meshes, material assignments or provenance change. If you manually destroy the experimental markers or materials, reopen your saved `.blend` backup. Blender native validation for 5.1.1 is still pending.

## Roadmap

- E3.4.4: Optional **Si — Idle Ink** preset based on winning E3.4.1 A, not a universal default.
- E3.4.5: Native cross-character and repeat-Build validation before any universal FX auto-apply.
