# SaberShader 1.0.4 — E3.4.4 Si Idle Ink Fidelity Preset

E3.4.4 is an **explicit, reversible** Si-specific preset layered on the existing, actor-agnostic E3.4.3 control policy. It does **not** make all Arknights: Endfield FX look like Si's ink.

## Why a separate path?

Si's seven `S_actor_jsspsi_vfxpart_0[1-7]_lod0` idle FX objects use the original source identity `DefaultHGMaterial`, which has no authored `_MainTex` that can satisfy E3.4.3's strict source-JSON criterion. E3.4.4 therefore requires the independently verified A graph from E3.4.1 (or the exact nested `SaberShader - Mask` graph) and copies it privately before any look adjustment.

## Scope and invariants

- **A:** original current material ID, unchanged, including any nested source node group.
- **A2:** a new material ID; nested group is independently copied before adding nodes.
- Exactly seven Si idle `vfxpart` LOD0 meshes, all using the *same* local material with source `DefaultHGMaterial`.
- No change to iris, EyeShadow, ordinary character materials, cloth FX, other AE operators or General/FGO/Uma profiles.
- E3.4.1 parent A/B sessions are supported **only when Show A is active**. The verified automatic E3.4.5.1 main-Build A is also accepted as an independent baseline (it is validated by token, material identity and shader hashes). Restore E3.4.4 A before returning to E3.4.1 or rebuilding. 
- Build main and direct AE Full Setup are blocked while E3.4.4 is active. No implicit **A2 preset** application after Build. E3.4.5.1 may apply the separate single-trail **A baseline** automatically for a verified Si main Build.
- Original and preview graph topology/identity guards fail closed if a scene is manually altered during A/A2.
- A2 is an approximation in Blender, **not** a reverse-engineered Unity shader or an in-game verified match.

## Default A2 values (visual hypotheses, not extracted from game)

| Control | Value |
|---|---:|
| Alpha Power | 1.08 |
| Alpha Multiplier | 0.96 |
| Edge Fade | 0.02 |
| Brightness | -0.02 |
| Contrast | 0.045 |
| Tint RGB | (0.92, 0.93, 0.94) |
| Emission Gain | 0.90 |

The controls use E3.4.3's exact bounds and validation, but target Si's demonstrably connected `T_fx_trail_gfx_18.png` single-trail RGB and alpha routes, not an invented universal texture assignment.

## Blender 5.1.1 usage

1. Work in a **copy** of Si's good `.blend` with EyeShadow fixed. Disable older SaberShader packages, close Blender and install this full addon ZIP; reopen Blender.
2. If E3.4.1 is active, **Show A** before E3.4.4 Prepare. If not, E3.4.4 can accept only a positively verified original `SaberShader - Mask` A node graph. If neither case applies, prepare/Show A using E3.4.1.
3. Open Sidebar `N` > `SaberShader` > `Arknights: Endfield` > **AE Si Idle Ink Fidelity Preset E3.4.4**.
4. Press **Prepare A/A2 (No Visual Change)**. Then compare **Show A** and **Show A2** with the same camera, lights and exposure.
5. Adjust sliders, click **Apply Controls to A2**. `Reset Preset Dials` resets the GUI controls; press Apply to commit these values to A2.
6. `Record A/A2 Metadata` outputs a timestamped JSON path to the Blender console. Keep front / three-quarter / profile screenshots with identical render settings.
7. **Restore Original A**. If E3.4.1 was the parent, you can then continue its A/B experiment or **Restore Original Si VFX (A/B)**.

## Safety limitations

- No automatic handling of arbitrary `DefaultHGMaterial` placeholders: only the seven verified Si mesh IDs and exact established A graph are eligible.
- Linked or multi-user mesh data, different Si baseline materials and manually reassigned targets are blocked.
- Shader graph tampering while a session is active is blocked. If recovery is blocked, use the `.blend` backup.
- No native Blender 5.1.1 or game-side color measurement was available during package creation. Run the QA protocol before considering the visual result accepted.
