# SaberShader 1.0.4 — E3.4.5.1 | Si Idle Ink A in Main Build

**Change:** For a source-verified, single-actor Arknights: Endfield **Si** (`jsspsi`), the standard **Build SaberShader** now attempts to leave the **E3.4.1-style A (gfx18 single trail)** visible on exactly seven original `vfxpart_01..07_lod0` meshes. The automatic result is distinct from the manually staged E3.4.1 A/B session, and is **not** the E3.4.4 A2 preset. No universal FX material is automatically converted to Si ink.

## Existing manual A/B session: one-time migration

If `E3.4.1 | Si Idle Ink A/B Study` currently says `Active A/B session: 7/7` and `Showing: A` as in the reported screenshot, click **Restore Original (A/B)** **once before the first Build** with this update. If E3.4.4 A2 is active, restore E3.4.4 *first*, and then restore E3.4.1. Those manual research sessions remain protected against Build; no experiment is silently discarded.

After installing the complete updated ZIP and restarting Blender, select Si's armature / all seven meshes and click **Build SaberShader**. The panel then reports `Build A: ACTIVE (7 Si meshes)` if successful. The scene telemetry property `SaberShader_AE_SiBuildA_Status` is `ACTIVE_A`, `ACTIVE_A_REUSED`, `ALREADY_EXACT_A`, or an explicit skip/error status. Check the **System Console** and Blender reports for warnings when A cannot be safely applied.

## How the guarded integration works

1. The existing main AE Build runs **once**, with the same verified source/actor owner checks. E3/E3.1/E3.2/E3.3.2 still work on the original baseline.
2. After the established Si shader stages and E3.3.2 read-only validation, the new scoped stage runs. It uses **the existing E3.4.1 Single Trail constructor**, which targets the gfx18 RGB and alpha texture, or respects a positively detected exact nested Mask A. When missing/ineligible, **the stage skips or errors; it does not fake an A result**.
3. For a non-native A, a private material copy is assigned to the seven exact mesh data material slots. Original material ID, original fake-user state and an A shader fingerprint are retained in per-mesh metadata. The main Build does **not** stage B, does **not** set E3.4.1 A/B tokens, and does **not** apply E3.4.4 color/opacity controls automatically.
4. **Repeat Build:** the current A is validated (identity, graph, provenance, no foreign users); its exact material is temporarily retained while the original material is presented to the guarded legacy Build. After successful pipeline stages the **same A ID** is reassigned. Thus a repeated Build must not create a new A or B research copy. If Build cancels, it attempts safe A recovery; if source assignments have changed, it refuses a speculative restore and reports `RECOVERY_REQUIRED`.
5. The E3.4.1 **Show A / Show B** buttons remain manual and reversible. When a manual A/B session is active, main Build remains **blocked** until that session is restored. E3.4.3 universal and E3.4.4 Si A2 studies still retain their existing guards.
6. A separate **Restore Pre-A Si VFX** button in the Si panel explicitly returns the seven meshes to the material present immediately before auto A (the original shader datablock), removes the private auto-A material if unused and restores the original fake-user state. A later main Build will reapply A if the source is still eligible.

**Safety:** no scene-wide material replacement; no modifications to eye, body, hair, cloth or other actors; no automatic A on General/MMD, FGO, Uma or other Endfield actors. Linked, shared, incomplete, artist-edited and ambiguous material states fail closed. No game assets or PNG textures are bundled. An automatically produced A approximation is not a reverse-engineered Unity shader.

## E3.4.5 cross-character QA after this change

The E345 workflow stays **opt-in**. Use the resulting auto-Build A as Si's baseline for E3.4.4 A/A2. Restore E3.4.4 after its test. If you *also* opened a **manual** E3.4.1 A/B session, restore that parent before the Repeat Build baseline. You should **not** restore the new auto-Build A before its Repeat Build test: it is the intended default built result, and its material identity should stay stable across the two captures. E345 still rejects actual modifications to non-target data; it has not been relaxed to hide shader changes.

## Required Blender validation (not included in offline tests)

- Blender 5.1.1: exact seven Si VFX A applied by the main Build; same view/frame/colorspace as manual E3.4.1 Show A.
- Repeat Build: compare material ID, nodes/links, transparency and source-image colorspace before and after. Check E345 `PASS_STATIC` vs actual rendered behavior.
- Manual E341 A/B and E344 A2: restore exact intended original IDs and confirm the default auto-A material is not overwritten.
- Build failure: restore A unchanged if the underlying Build has not touched the source; if it has, inspect the saved `.blend` backup. Never force a mismatched material assignment.
- Other AE actor and FGO/Uma/General: verify no automatic Si ink stage executes.

**Validation performed here:** source inspection, Python compilation, 15 simulated Build-A state tests and 11 inherited E345 pure-logic tests. No native Blender executable or complete Si/second-character `.blend` was available for this update. These offline tests are **not** a native Blender render/behavior certification.
