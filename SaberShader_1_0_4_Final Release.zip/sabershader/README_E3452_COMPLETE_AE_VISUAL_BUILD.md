# SaberShader 1.0.4 — E3.4.5.2 | Complete AE Visual Build

## Problem and change

Previously, the **Build SaberShader** button used the AE Full Setup pipeline but `ae_auto_profile.prepare()` only filled **unset** Blender RNA flags. Many existing `.blend` projects retained explicitly stored `False` values (for example `ae_outline_enabled=False` and `ae126_grade_enabled=False`). The legacy Build then skipped the real feature. Separately, scene **AE126 Color Management** was available only via the manual `Apply AE View` button. The eye overlay was already in the Build as AE123, but could be explicitly disabled or blocked by missing authenticated source assets.

From E3.4.5.2, with **Complete AE Visual Build (automatic)** enabled (the existing `ae_auto_profile_features` setting, default ON):

1. Identify a **currently source-verified Arknights: Endfield** model with **one unambiguous owner actor**, using the same existing engine preflight; a matching name alone is insufficient.
2. Before the **one and only** legacy Build, enable the stable source-gated visual stage switches: diffuse ramps, hair, cloth specular, eyes/iris, lighting material polish, render-grade nodes, scene-responsive face, hair rim, final highlight compression, **AE110 outline**, **AE123 eyeshadow/iris LOD protection**, and reversible helper cleanup. This now also turns on explicitly stored OFF stage toggles from an older `.blend`. **Numeric tuning/UV data/presets are not reset**, the `SOURCE` fidelity preset still excludes extra artistic grading, and source-asset guards in the underlying engine are not bypassed. Exact Wulfa source verification additionally enables the previously verified HF2 RG normal reconstruction; other characters are not opted into HF2. Final hair debug views are restored to `FINAL`, and face response uses the previously validated `SCENE` mode when the artistic preset is not `SOURCE`.
3. Run the original guarded AE Full Setup and shader Build **once**. The existing AE110, AE123 and hair/cloth/face code remains responsible for actual material and geometry operations.
4. Only after a successful, still-verified AE Build, and after rechecking owner provenance, apply the **AE126 Khronos PBR Neutral / sRGB / None / 0 exposure / 1 gamma** scene View settings with the same transactional snapshot used by the old manual `Apply AE View`. The existing **Restore View** button still restores the saved previous scene view. If the OCIO configuration rejects Khronos PBR Neutral, the prior View is restored and a warning is shown. No loaded image's *texture* colorspace is changed.
5. Report actual `Outline / Eyeshadow / Color` results in **Endfield tools**. `COMPLETE` only describes these observed stages, **not visual parity with Unity**. `PARTIAL` means inspect the stated skipped feature; a missing JSON, UV0, unique LOD0 or eligible outline role must never be reported as applied. Repeat Build recognizes a source-verified pre-existing eyeshadow overlay and does not require a new overlay creation every time.
6. For Si only, execute the existing E3/E3.1/E3.2/E3.3.2 and **E3.4.5.1 automatic Single Trail A** stages afterwards, preserving their material identity, A/B safety barriers, restore and Repeat Build behavior. Other verified AE actors never inherit the Si preset.

## Deliberately separate from the automatic visual Build

- **Audits and logs:** manual E3.4.2 source inventory, AE Material/UV Audit and Si source audit are no longer invoked by the one-click wrapper. The legacy core still records its already-integrated task diagnostics and Si-specific safety check; no user action is needed to keep those checks.
- **A/B research and experimental previews:** E3.4.1 manual A/B, E3.4.3 universal A/A2, E3.4.4 manual A2 tuning, hair/SDF debug probes and Geometry Nodes Ink previews. They are not final, universally verified FX builds. In particular E3.4.4 A2 is not substituted for the Si A requested in E3.4.5.1.
- **Reversible administrative actions:** Restore, Delete, manual LOD visibility selector, Create/Remove 3-point preview lights, source audits. These are not shader stages. An incompatible existing A/B study still blocks Build until its precise Restore step completes.
- **Exact-source dependencies:** Face SDF light target and unverified UV/channel selection are not guessed; when the source does not provide a feature, the actual shader builder skips it.
- **Other profiles:** General/MMD, Uma Musume and FGO Arcade use their original `aef.add_shaders_v11` flow. Neither automatic AE flags nor AE126 View changes are applied for their Builds.

## Runbook for Blender 5.1.x

1. Save a separate `.blend` copy. Disable the previous addon, exit Blender completely, install the **complete** E3.4.5.2 ZIP and restart. Do not merge individual `.py` files or keep two versions enabled.
2. If Si has an **active manual** E3.4.1 / E3.4.4 comparison, use **Restore Original** before the first Build. Do not restore an already-automatic E3.4.5.1 Si A just to repeat Build.
3. Select the verified Endfield armature/actor, and set its correct `Textures` or model root path. In `Endfield tools → AE Full Setup & Build Options`, keep **Complete AE Visual Build (automatic)** on. Click the top-level **Build SaberShader** once.
4. Verify **Outline** is `APPLIED_N_SHELLS`, **Eyeshadow** is `APPLIED_N_OVERLAYS` or `PRESERVED_VERIFIED_OVERLAY`, and **Color** is `APPLIED_PBR_NEUTRAL` or `ALREADY_PBR_NEUTRAL`. Check the scene View in **Shading & Lighting → AE Color Management** and the material in Rendered mode. If any status is `PARTIAL`, read the detail in scene custom property `SaberShader_AE_CompleteBuild_Detail` and the native AE123/AE110 report.
5. Perform a **second Build** and compare source mesh/material identity, number of AE outline shells, eye shadow material and scene color. Then test a **non-Si AE** and an **FGO or Uma** scene. After an unrelated-profile Build, previously chosen scene View settings are not automatically reset; use **Restore View** if appropriate.

## QA status

The ZIP includes Blender-free unit tests for explicit prior OFF flags, canceled-Build rollback, source validation, other-actor rejection, SOURCE preset, color-View rollback and repeat Build. This package has **not** been run in native Blender 5.1.1 with Si / Wulfa models and original JSON/PNG sources; output is not certified until those scene tests pass. All implementation changes remain additive and isolated from the original shader generator; no game assets are bundled.
