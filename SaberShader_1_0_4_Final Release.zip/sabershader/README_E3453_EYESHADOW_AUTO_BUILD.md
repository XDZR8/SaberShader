# SaberShader 1.0.4 — E3.4.5.3 | AE EyeShadow Post-Build Guarantee

## Why this patch exists

The character Si (`lizhiyan`) can display **white bands over the eyes** when `S_actor_lizhiyan_eyeshadow_01_lod0` retains the generic `SaberShader - Eyes` material rather than the Endfield authored transparent eyelid mask. E3.3.2.4 had already fixed the sibling-file resolution for `Materials/M_eyewhiteshadow_common_01.json` plus `Textures/T_actor_common_eyeshadow_01_M.png`. E3.4.5.2 enabled AE123 eye setup by default, but it displayed a summary from legacy **counters**, which could miss a still-white actual material.

E3.4.5.3 adds a **single, source-verified post-Build check** to the existing main `Build SaberShader` dispatcher. It is **not a second shader Build**.

## Exact behavior

1. Only after a successful legacy Build and **current authorized AE verification**: check the same single-actor owner/preflight, source iris JSON, and AE Full Visual Build setting.
2. Require **exactly one** `S_actor_<actor>_eyeshadow_<variant>_lod0` mesh (not a generated outline helper), with UV0, a unique material slot and the original validated eye-shadow JSON + PNG mask. Source lookup accepts the model root, `Materials/`, or `Textures/` as in E3.3.2.4.
3. Check the **real material output**, not saved AE119/AE123 tags or `overlays=0`: authored PNG mask is connected to the surface of the actual LOD0 material and that mesh remains visible. If verified, mark `ALREADY_READY` and do not touch it.
4. Otherwise call the existing `_xdzr8_ae123_eye_full_setup` **once**. It already owns the authored JSON color, red-channel grayscale alpha, transparent/emission shader, LOD safety, stale override recovery, manual customization protection and original-material snapshots. Reinspect the material after that attempt; mark `REPAIRED` only if genuinely ready.
5. If source files, UV0, single-actor evidence, LOD0, visibility or manual protection prevents a repair, **do not paint the band dark, guess a mask, hide it or report success**. Show `PARTIAL` and the problem in Endfield tools, and keep the prior custom/owned materials.
6. The earlier outline, scene color, hair, FX, Si Single Trail A, restores, A/B and cross-character QA remain unchanged. FGO, Uma and General do not run the AE eye stage.

## How to test on Blender 5.1.x

1. Save a backup `.blend`; disable prior SaberShader installs, **exit Blender completely**, install the **whole E3.4.5.3 ZIP**, start Blender again. A previous white-band incident was caused by a stale in-memory `engine.py`; mixing Python files is unsafe.
2. Select the Si armature/character; set the correct source folder (`.../Si/Animator/.../Textures`, sibling `Materials` required). Keep `Complete AE Visual Build (automatic)` enabled.
3. Click **Build SaberShader**. In `Endfield tools → Last AE Visual Build`, the desired eyeshadow status is `REPAIRED_1_OVERLAYS` (if legacy AE123 missed it) or `PRESERVED_VERIFIED_OVERLAY` (legacy already did it). Inspect the actual `S_actor_lizhiyan_eyeshadow_01_lod0` material in **Material Preview** or Rendered shading. It should use the authored transparent overlay, not a white opaque strip.
4. Build **again**. Eye should read `PRESERVED_VERIFIED_OVERLAY` with the same material slot/mesh. No second overlay material should be created by E3.4.5.3.
5. If the status is `PARTIAL`, read `SaberShader_AE_EyeBuildE3453_Status` and `...Detail` from scene custom properties. `BLOCKED_MISSING_MASK` specifically means that the original JSON/PNG were not resolved; it is **not** safe to fabricate the texture. The existing `SaberShader_AE124_Eye_FullBuild_Audit` may also help locate the missing prerequisite.
6. Confirm no AE eye repair occurs when building another profile; test with Wulfa as a non-Si AE character if its source files are complete. Other AE actors can use this exact guarded method, but no Si-specific assumptions are baked into the new stage.

## QA limitations

Automated tests are offline Python simulations, not full Blender 5.1.x execution. Native material-render and second-character validation remain open. No original game data or textures are bundled.
