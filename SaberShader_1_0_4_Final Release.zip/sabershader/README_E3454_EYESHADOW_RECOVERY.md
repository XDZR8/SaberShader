# SaberShader 1.0.4 — E3.4.5.4 | AE EyeShadow Build Source Recovery

## Motivation

E3.4.5.3 inspected the real LOD0 node graph but its repair still used the *configured* texture folder even when the engine had recovered a different *effective* source folder for the successful Build. AE123 also skipped an LOD0 if its mesh datablock was shared, even though an object-linked material slot may be assigned without changing shared geometry. These are **confirmed code gaps**, not proven to be the cause of the user's current Blender scene failure.

## Changes

- Main verified AE `Build SaberShader` continues to run **one** core Build. After success, E3.4.5.4 checks the exact LOD0 eye material and calls existing AE123 only if the original source mask does not reach Material Output.
- Use source roots in priority order: `settings.universal_texture_folder`, then `SaberShader_AEStateV1_EffectiveSourceFolder` stored by the **just-completed** core Build. Both require original `M_actor_<actor>_iris_*.json` provenance, `M_eyewhiteshadow_common_01.json`, and `T_actor_common_eyeshadow_01_M.png`. Never infer an actor from a white strip or substitute an invented mask.
- In AE123, accept mesh datablocks with multiple users if the exact LOD0 has UV0 and a single material slot. Before assigning the mask, `slot.link = 'OBJECT'` isolates the material to this object. Do **not** duplicate or alter the mesh, armature, UVs or other owners.
- Persist observable reason codes under scene keys `SaberShader_AE_EyeBuildE3454_` (`Status`, `Detail`, `Material`, `Graph`, `SourceMode`, `Actor`); previous E3.4.5.3 state remains intact.
- **Eye Repair & LOD Guard > Inspect why EyeShadow was skipped** writes a read-only report to Blender's Text Editor: `SaberShader_E3454_Eye_Build_Diagnostic`. It reports chosen source root, actual material slot, `UV0`, sharing, graph validity, previous error and visibility. It does not contain texture pixels.
- If the last core Build did not commit verified AE authorization, record `SKIPPED_UNVERIFIED` instead of leaving an ambiguous stale success code.
- Source and ownership guards, custom/manual material protection, source-mask red channel, color JSON, outline, Si Ink A/A2 and FGO/Uma/General isolation are unchanged.

## Reproduction / verification (Blender 5.1.x)

1. Back up `.blend`. Disable the old addon; **close Blender**; install the complete E3.4.5.4 ZIP and restart.
2. Select the Si armature or any mesh in its actor, set its source path and leave **Complete AE Visual Build (automatic)** ON.
3. Click **top-level** Build SaberShader (not the legacy FGO-specific button). In **Endfield tools > Last AE Visual Build**, inspect Eyeshadow. `REPAIRED_1_OVERLAYS` or `PRESERVED_VERIFIED_OVERLAY` proves *graph wiring*, **not visual fidelity**.
4. If white strips remain, expand **Eye Repair & LOD Guard** and click **Inspect why EyeShadow was skipped**. Open `SaberShader_E3454_Eye_Build_Diagnostic` in Blender's Text Editor and copy its contents. This identifies whether the failure is source resolution, metadata, visibility, slot ownership, or graph wiring. Include a render/material preview; image alpha/renderer differences require native investigation.
5. Repeat the Build and check material graph/scene status. Validate with a non-Si AE model and unrelated FGO/Uma projects separately.

## QA limits

Offline Python compilation and 68 mock/unit tests complete. Not tested inside Blender 5.1.1 with the user's real Si model and original texture files. No assertion of final visual correction until that test. Do not overwrite a manually edited eye material; that is a guarded skip by design.
