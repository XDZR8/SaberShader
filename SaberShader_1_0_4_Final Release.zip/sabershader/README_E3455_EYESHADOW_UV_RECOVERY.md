# SaberShader 1.0.4 — E3.4.5.5 EyeShadow UV Layer Recovery

## Proven cause from Blender diagnostic

A real E3.4.5.4 diagnostic reported:

```
AE eye mask: Before= [MISSING_UV0]; after= [MISSING_UV0]; AE123=VERIFIED;
SKIP MISSING UV0 S_actor_lizhiyan_eyeshadow_01_lod0
```

`source_ready=true`, `ae_state=VERIFIED`, and one primary LOD0 eyeshadow
were confirmed. `uv0=false` indicated that no layer *named* `UV0` was found,
not whether the mesh contained UV layers with other names. Because the old
validator returned early, the blank `material` field did **not** establish that
its material slot was empty.

## E3.4.5.5 scope

The AE123 source-mask Build uses `_xdzr8_ae123_eye_uv_layer`:

- `UV0` present: use `UV0` as before.
- `UV0` absent and exactly one UV layer exists: use that layer's original name,
  e.g., `UVMap`; do **not** rename, delete, create, or unwrap UV layers.
- No UV layers: report `NO_UV_LAYERS` and do not assign a source-mask overlay.
- Multiple layers without `UV0`: report `AMBIGUOUS_UV_LAYERS` and preserve the
  existing material. Selecting one would be an unverified source-UV guess.

The original JSON, PNG, actor identity, protected manual materials, original
material snapshot, per-object slot binding, LOD guards, and Build authorization
remain in place. The source mask is now connected to the chosen UVMap node.
For non-`UV0` mapping, a separate SaberShader-owned material name prevents
accidental cross-mesh UV changes. Existing material nodes and output connectivity
are checked along with the UVMap-to-source-image link; mismatch triggers
recovery rather than a false "already ready".

The AE124 eye audit treats an unambiguous source UV as valid rather than
requiring its name to be `UV0`. The E3.4.5.4 diagnostic operator retains its
stable Blender `bl_idname` for compatibility but writes a new read-only report:
`SaberShader_E3455_Eye_Build_Diagnostic`. It now includes `uv_layers`,
`uv_layer_count`, `selected_uv`, `uv_decision`, and the **actual** material name
regardless of the early UV checks.

## Usage

1. Save a copy of the `.blend` before changing the add-on.
2. Disable the old add-on, close all Blender processes, and install this ZIP.
3. Open the affected scene, select Si, and press **Build SaberShader**.
4. Under **Endfield tools → Eye Repair & LOD Guard**, run
   **Inspect EyeShadow UV & Mask** and read the text datablock
   `SaberShader_E3455_Eye_Build_Diagnostic`.
5. Compare before / after, and run Build a second time. `ALREADY_READY`
   means the graph was verified and was not rebuilt by the post-Build recovery.

`REPAIRED` or `ALREADY_READY` confirms source-mask graph connectivity, not
pixel-perfect in-game fidelity; visual inspection in Blender 5.1.x is still
required. If `NO_UV_LAYERS` is returned, recover original UV coordinates
from the source asset or re-import the original geometry with its UV data.
Never unwrap arbitrarily or fabricate UVs from screen coordinates.

## Offline QA

Tests cover exact UV0, sole alternative name, missing/ambiguous UV layers,
no in-place UV changes, material snapshot & per-object slot assignment, wrong
UV material rebuilding, Repeat Build, and UV node linking. These do not replace
native Blender and visual multi-character tests.
