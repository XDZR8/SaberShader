# SaberShader 1.0.4 — E3.4.5.6 | AE User UI Cleanup

## Objective

Keep **Build SaberShader** as the single automatic visual build entry point for
Arknights: Endfield. Normal users should not have to navigate shader stages
that Build already handles, nor see QA experiments or JSON-export panels.

This is a **UI-only** change on top of E3.4.5.5, whose EyeShadow UV-layer
recovery was confirmed working in Blender. The shaders, scene corrections,
operator identifiers, settings values, underlying QA and stage modules have
not been modified. Hide panels; **never disable their Build functions**.

## Normal AE interface (default)

Under **SaberShader > Arknights: Endfield**:

- AE source verification and concise last-Build status, including a warning if
  EyeShadow still needs attention.
- **Display LOD (Optional)**: select a LOD and restore original mesh visibility.
  This is a manual display operation, not part of Build.
- **Preview Lighting (Optional)**: create/update or remove the additive
  three-point lighting preview. Not run automatically by Build.
- **Restore Previous AE Settings** only when a Build settings backup exists.
- If an old Si A/B session blocks Build, an explicit **Restore Original Si VFX**
  action is offered. Suspended automatic Si A can also be recovered.

Normal AE UI does **not** display these previously exposed controls:

- Per-stage shading/lighting, face/hair, hair fidelity/compression, cloth/iris,
  eye repair, outline, ink material/GN tuning, Full Setup & Build switches.
- Material & UV audits, Si source-dictionary audit, universal FX foundation,
  A/A2 and A/B tests, Si idle-ink experimental preset, or cross-character QA.
- JSON report/export buttons, comparisons, data dumps and test-only previews.

## Developer mode

Blender **Edit > Preferences > Add-ons > SaberShader > Show AE Developer Tools**.
When enabled, the complete legacy inline Endfield sections and registered
research/audit/validation panels become visible again. These tools remain
available to maintainers without burdening general users.

The flag is an AddonPreferences value (default **OFF**), **not** a scene
property; it does not alter .blend files, artist presets or Build behavior.
Registered RNA class/operator names and scene properties are preserved.

## Preservation / safety

- `engine.py`, `ae_one_click.py`, AE123 source recovery and all other shader
  pipeline files are byte-identical to E3.4.5.5.
- No Build stage is skipped because its UI panel is hidden.
- Existing source authorization and scene-safety guards are unchanged.
- FGO Arcade, Uma Musume and General/MMD panels are not reorganized.
- Prior `.blend` scenes do not need a migration.
- Saved scenes with an active Si A/B session retain a public recovery button.

## Verification

Offline test suite: 85 tests, including E3.4.5.6 UI policy tests, all passed.
Python syntax compilation passed. Blender 5.1.x native UI registration / visual
verification **has not** been performed in this environment.

### Blender acceptance checklist

1. Disable the previous addon, close Blender, install the ZIP and restart.
2. Open Si (verified AE). In default mode, check that only the public controls
   are visible and that no JSON/audit research panels show.
3. Press **Build SaberShader**. EyeShadow, outline, shading and color must
   match the already working E3.4.5.5 result.
4. Build again; verify no difference and no new unexpected data.
5. Enable **Show AE Developer Tools** in Add-on Preferences; confirm the old
   controls return, including E3.4.5.5 diagnostic and E3.4.5 cross-validation.
6. Disable the option; verify the public UI becomes compact again.
7. Open an FGO or Uma scene; ensure its own build/panels remain unchanged.
