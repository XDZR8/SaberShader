# SaberShader 1.0.4 — Endfield naming and code documentation cleanup

## Purpose

Preserve the known-working E3.4.5.5 eye-shadow UV recovery and E3.4.5.6
user-interface visibility policy while replacing developer milestone codes in
**Blender-facing copy** with stable functional names.

This release is a presentation/documentation change. It does **not** change the
profile detection predicates, UV resolution rules, shader graph builders,
operators' `bl_idname` values, registered classes, scene ID-property keys,
material tags, revision constants, numerical presets or safety checks.

## User-facing labels

- The normal Endfield panel remains compact and Build-centered.
- Developer-only labels now use feature terminology, for example:
  - `HF4.2 Preset` → **Specular Calibration Preset**
  - `Enable HF4.5 Hair Rim Light` → **Enable Hair Rim Light**
  - `Enable HF4.5.1 Face Light Recovery` → **Enable Face Light Recovery**
  - `AE Cross-Character Validation E3.4.5` → **Cross-Character FX Validation**
  - `Inspect AE Eye Build (E3.4.5.5)` → **Inspect Eye Shadow Build**
- Build reports and add-on restart errors use actionable descriptions instead
  of release-stage numbers.
- User-facing text and tooltips are polished in English to match the existing
  interface language; untranslated source filenames and file formats are kept.

## Identifiers intentionally retained

- Class names such as `AEF_OT_ae123_apply_eye` and RNA properties like
  `ae129hf45_enabled` can be referenced by existing files and scripts.
- Historical scene keys such as `SaberShader_AE_EyeBuildE3454_Status` are
  persisted in saved scenes and are therefore **not** renamed.
- Existing filename suffixes, JSON schema fields, revision signatures, shader
  node names and material ownership tags remain exact for interoperability.
- Development documentation retains patch references where they aid debugging,
  but they do not belong in labels or end-user status messages.

## Commenting style for future changes

1. Describe **what** a stage changes and **when** it runs, not only the date or
   numbered patch in which it was introduced.
2. State safety preconditions (verified AE actor, exact eligible mesh/material,
   available original JSON/PNG, valid UV layer) and what triggers a skip.
3. Document repeat-Build behavior, rollback/restore ownership and expected
   states, especially for eyes, source colors and Si FX.
4. Distinguish *verified source behavior* from *approximation* and *research*
   without claiming fidelity that has not been tested in Blender.
5. Hide research/audit tools via the UI policy, never by removing the operator
   registration or disabling its underlying Build stage.
6. Keep internal IDs stable. Make only the human-facing `bl_label`, operator
   `text`, property `name`/`description` and message strings readable.

## What has been reviewed

- Endfield developer labels and tooltips in `ui.py` and `engine.py`.
- FX/EyeShadow/Si comparison operator labels in the dedicated modules.
- Main Build status messages in `ae_one_click.py`.
- Core module responsibilities and restoration contracts in module docstrings.
- Restart messages in `__init__.py`.
- Main README and the developer-oriented naming guide.

## Verification and native acceptance

Run the bundled tests and compile the package. Inspect changed string literals
and confirm that no routing, material mutations or persistent IDs changed.
Then in Blender 5.1.x:

1. Confirm the public AE panel remains compact and version-code-free.
2. Perform Build on Si and verify the same correct eye-shadow mask, FX, outline
   and color result as the prior confirmed build; repeat Build once.
3. Switch Developer Tools on and verify the descriptive labels and access to
   the original audits, reports and recovery operators.
4. Check an FGO/Uma project to ensure profile isolation.

Offline checks do not constitute a successful native Blender visual test.
