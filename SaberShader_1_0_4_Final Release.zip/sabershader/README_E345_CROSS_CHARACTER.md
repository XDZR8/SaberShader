# SaberShader 1.0.4 — E3.4.5 Cross-Character Validation

**Status: QA instrumentation implemented; actual second-actor Blender validation NOT yet completed.** This QA module is **opt-in** and makes no shader writes. The separate E3.4.5.1
main-Build integration now produces auto-Build **Si A**, which this instrumentation
can observe as the Si A/A2 baseline. E3.4.1, E3.4.3 and E3.4.4 manual previews
remain opt-in and preserve their original protections.

## What is validated

- Exact **AE actor** selected and currently source-authorized; full FX source inventory (source JSON, `_MainTex` file provenance, conservative E343 graph eligibility).
- All mesh identities/slot links/visibility/transform values and all material graph/input/provenance and file-image metadata in the `.blend`, including unrelated actors and profiles.
- **A2 preview:** only original-to-A2 slot substitutions explicitly validated by E343 or by E344 for the *seven* Si idle FX may differ. A's shader, image datablocks and every unrelated material must remain unchanged. The original material's **temporary fake-user flag** is the only allowed original-material metadata difference.
- **Restore:** all original material IDs, graph values, image filepaths/colorspaces, mesh slots and settings must match the first snapshot; no E343/E344 tags or A2 material residues.
- **Repeat Build:** a *distinct*, completed AE Full Setup execution for the same actor, identical scene/material/image FX inventory, no pending A/A2. This can uncover non-idempotent Build behavior; it does not correct it.
- **Cross character:** two separately exported complete actor evidence JSONs, one Si (`jsspsi`) and one another AE actor with at least one eligible source-authored, output-connected `_MainTex` FX material. No fuzzy character or shader identity is accepted.

**`PASS_STATIC` means a structural test passed.** It does **not** mean runtime animation, render fidelity, transparency appearance or Unity/game parity passed. `INCOMPLETE_OR_FAIL` is retained for missing evidence. A legitimate procedural FX / `DefaultHGMaterial` placeholder is *classified* but cannot count as a universally supported E343 A2 test.

## Workflow for each character in Blender 5.1.1

First save a **copy** of a working `.blend`. Install this full ZIP (disable old addon and restart Blender). Complete one verified AE Full Setup Build; select one actor mesh. Under `N > SaberShader > Arknights: Endfield > AE Cross-Character Validation E3.4.5`:

1. **Capture A/A2 Baseline.** On Si, parent E3.4.1 (if used) must show **A**. E343/E344 must not be active.
2. Use the existing **E343** A/A2 for an eligible non-Si `_MainTex` FX (select a participating mesh for E345), or **E344** for Si's seven ink meshes. Switch fully to **Show A2**. **Validate Visible A2**. Compare identical camera/light/frame screenshots manually.
3. Click **Restore Original FX** in E343, or **Restore Original A** in E344. Then **Validate Restored A** in E345. If on Si, restore the parent **E3.4.1 A/B** *after* this step.
4. **Capture Build Baseline** after all *manual* E341/E343/E344 comparisons are closed. Keep the new automatic Si Build A visible; it is the intended built state, not an active E341 experiment. There must be an actual previous completed AE Full Setup execution for this actor. Run the **main Build SaberShader** again (it safely suspends and reuses auto A). Then **Validate Repeat Build**. The run's unique execution ID must change, and status must be `FINISHED`. Do not use direct guarded AE Full Setup when auto A is active: it intentionally asks you to use the main Build.
5. **Export Actor Evidence**. File is timestamped JSON in the OS temp directory, printed to Blender's System Console. Repeat on the second actor **in a different `.blend`**. In either Blender session, select both files in the E345 panel and click **Compare Si + Second AE Actor**.

**Errors:** if a phase reports `FAIL`, inspect the exported JSON `failures` (no implicit retry/repair). A failed phase cannot become a full `PASS_STATIC` actor evidence. `Reset E345 Evidence` deletes only E345 Text reports and scene pointers in the active scene; does not modify FX materials or other audit data. Do not reset just to hide a failure: first investigate in a copy.

## Visual QA matrix (must be performed manually)

| Check | Si baseline | Second actor |
|---|---|---|
| Source provenance and FX family | Si default placeholder ink, strict E344 original-A graph | Exact source JSON + `_MainTex` PNG etc. + E343 output graph |
| A/A2 same frame, view, color management and lights | Screenshot A/A2: shape, edge, density, color | Screenshot A/A2: native authored FX characteristics |
| Restore (A exact) | E344 then E341 parent | E343 |
| Textures/material isolation | Other seven targets, body/eyes/clothes unchanged | Non-FX character materials/other actors unchanged |
| Repeat Build | After E341 restoration | After E343 restoration |
| Animation / timing / transparency | Review manually | Review manually |

E3.4.5.1 automatic Si Build A does not change E345's strict source-material/texture
fingerprints or broaden which second-character FX are eligible. Any changed
source graph or foreign material during Repeat Build still causes a failure.

If the second actor has **only procedural or unverified FX**, E345 correctly reports **not eligible**, rather than dressing those FX up as Si's ink. Use a different actor with provable source-authored FX; or collect source shader/texture evidence before widening E343 support.

## Technical limitations

- Blender 5.1.1 executable, game captures and second actor `.blend` were not bundled with this ZIP; **native/in-game QA is outstanding**. Python-only fixture tests validate the comparison logic, not Blender API behavior.
- The tool records evidence in `.blend` **Text datablocks**, plus explicit JSON exports. It does not touch scene material assignments, textures, source JSON, filesystem texture assets, Build output or other profiles.
- A scene can hold one E345 actor test session at a time. Baseline capture is persistent to allow restart; a new test needs explicit Reset.
- Legacy direct `bpy.ops.aef.add_shaders_v11` is not a supported guarded E345 Build path; use the standard main Build or safe AE Full Setup, not a low-level bypass.
- Fingerprints cover top-level and nested shader graphs and common node values, not pixel-by-pixel renders, animated evaluated mesh, external image file bytes, or arbitrary custom Blender node settings. Camera/frame and color-management parameters are checked, but screenshots still need controlled lighting.
