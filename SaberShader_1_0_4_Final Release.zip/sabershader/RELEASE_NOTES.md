## E3.4.5.6 — AE User UI Cleanup (2026-11-21)

- **Normal AE UI simplified:** automatic Build shader stages, source material
  dictionary, experimental A/B/A2 FX, validation and JSON audit panels are
  hidden by default. Public UI retains Build feedback, manual LOD selection,
  optional scene lights and recovery from blocked Si A/B or prior AE settings.
- **Developer-only panels:** Blender Add-on Preferences gains a
  `Show AE Developer Tools` setting (default OFF). Enabling it restores all AE
  stage/audit/test panels without removing any operator identifiers.
- **No shader changes:** the complete AE visual Build pipeline including the
  E3.4.5.5 EyeShadow UV recovery remains byte-for-byte unchanged.
- Offline UI policy + inherited tests: 85 passed. Blender 5.1.x native UI
  verification pending.

## E3.4.5.4 — AE Eyeshadow Source Recovery & Diagnostic

- Repair may now use the last Build's source-verified effective folder if different from the configured one.
- Shared-mesh LOD0 eyeshadow may receive a per-object material slot without modifying shared geometry.
- Show precise failure modes and a read-only Blender Text Editor eye report.
- This patch has only been tested with offline simulations; native Blender verification pending.

## 1.0.4 — E3.4.5.3 AE EyeShadow Post-Build Guarantee (2026-11-21)

- After a successful verified AE `Build SaberShader`, inspect the actual unique eyeshadow LOD0 material graph against the original `M_eyewhiteshadow_common_01.json` / `T_actor_common_eyeshadow_01_M.png` pair. A valid source mask is left untouched; otherwise retry the existing reversible AE123 eye setup once and verify again. No second shader Build.
- Preserve per-actor source checks, UV0, single-material/LOD guards, manual customization protections, LOD recovery and the warm source JSON color. Missing sources remain blocked with an explicit UI status rather than a guessed opaque replacement.
- The scene's Endfield status is `REPAIRED_N_OVERLAYS`, `PRESERVED_VERIFIED_OVERLAY`, or `PARTIAL` with a specific reason. Earlier A/B, Si A, outline, color management, and non-AE dispatch remain intact.
- Offline mocked regression tests (15 additional scenarios) cover idempotence, authentic source resolution gate, manual protection, other-profile isolation and error reporting. Native Blender 5.1.x rendering is still pending.

## 1.0.4 — E3.4.5.2 Complete AE Visual Build (2026-11-21)

- Verified one-actor AE Build enables all supported guarded final visual stages in **older and new .blend scenes**, including previously explicitly disabled outline, grade, eyeshadow, hair and cleanup flags. Exact Wulfa HF2 normals are also enabled when verified; final preview modes and the SCENE face-lighting branch are selected without changing numeric tuning. Custom numeric tuning and `SOURCE` preset retain their intended constraints.
- Integrates **AE126 scene View Transform** into the successful Build, with the existing original-View snapshot and Restore functionality. Does **not** alter texture image color-space assignments.
- Displays actual outline, authenticated eyeshadow and color-stage statuses, with warnings for missing eligibility and OCIO failures. No second material Build and no unverified shader/Unity claims.
- E3.4.5.1 auto Si A still runs at the end of the same AE Build; no A2 research preview is silently selected. Non-AE pipelines remain separate.
- Automatic one-click Material/UV, Si source, and universal FX inventory audits are removed from the visual wrapper; existing manual audits remain accessible. The legacy core's existing task telemetry is intact.
- QA: 43 isolated simulation/state tests (including 17 new cases) pass, package compiles and ZIP integrity is verified. Native Blender 5.1.x, real AE FX and non-Si cross-character visual QA are **not yet performed**.

### E3.4.5 — AE Cross-Character Validation (QA-only; 2026-11-21)
- Added `ae_fx_cross_validation_core.py` (Blender-free fail-closed snapshot and phase comparison policy) and `ae_fx_cross_validation_e345.py` (read-only FX/material inspection, persistent Text evidence, Blender UI operators, exported JSON).
- Requires verified Si + independent supported non-Si AE actor A2/restore/Repeat Build evidence before cross-character `PASS_STATIC`; no implicit Si preset on others.
- Full native Blender 5.1.1 / second-actor render QA remains pending; structural `PASS_STATIC` does not assert Unity visual fidelity.
- See `README_E345_CROSS_CHARACTER.md` for the exact workflow and exclusions.

## 1.0.4 — AE Universal FX A/A2 Fidelity Controls E3.4.3 (2026-11-21)

- Universal, manual A/A2 material preview for verified AE actor FX with exact JSON `_MainTex` source, proven output-connected node and supported alpha/color graph. No Si-specific texture or character IDs in new module.
- A is the exact existing material; A2 is a staged private copy with bounded neutral-by-default alpha power/multiplier, low-alpha fade, brightness/contrast, RGB tint and optional Emission strength gain.
- Single-actor grouping, shared-mesh/linked guards, exact restore by ID, no scene-wide material rewrites, no dynamic image colorspace changes, metadata snapshots with graph fingerprints. Active session blocks main Build and direct AE Full Setup.
- `DefaultHGMaterial` placeholders and procedural FX intentionally excluded. E3.4.1 Si A/B and source-only E3.4.2 audit remain unchanged. Si-specific idle ink preset planned for E3.4.4.
- Offline-only validation: QA kit includes inherited regression, pure numeric tests, functional fake-bpy graph tests and static integration checks. **Blender 5.1.1 visual and save/reopen validation remain required**.

## 1.0.4 — AE Si FX Idle Ink A/B Comparison E3.4.1 (2026-11-20)

- Adds explicit reversible A/B study for exactly seven original Si `vfxpart` meshes, within the Endfield Source Material Dictionary panel.
- A preserves the current nested Mask material **by exact datablock identity** when verified; otherwise stages a clearly labeled approximate Single Trail using `T_fx_trail_gfx_18`.
- B stages the existing E3.3.2 Dual Layer with the main/detail texture hierarchy reversed: `gfx_18` primary, `fj_09` secondary. No other Dual Layer strength/opacity parameters are changed.
- Full staged preflight, original retained for rollback, repeated switches do not duplicate materials, and **Restore Original** returns the precise previous material.
- During an active study, the main Build refuses to run so it cannot overwrite the visual comparison. The historical VFX_B Repeat Build issue outside the study remains unverified.
- A/B metadata export is read-only. No images/game assets bundled. Offline tests are not native Blender visual validation.

## 1.0.4 — AE Si EyeShadow source layout E3.3.2.4 (2026-11-20)

- Fix `_xdzr8_ae119_source_files` to search the exact source `Materials/` and `Textures/` sibling layout used by Si and other Endfield exports; previous AE123 eye overlay stage could not find the mask although Hard-Bind printed `mask=FOUND`.
- Accept configured model root, Textures, or Materials, retaining older flat-image layouts. Preserve exact JSON/PNG identity, `_UseGrayAsAlpha` and source color guards.
- No visual parameters, VFX materials, profiles, UI widgets, general build dispatch, or restore operators changed.
- 181 inherited + 6 isolated offline checks pass. Native Blender EyeShadow and Repeat Build validation still required.

## 1.0.4 — AE Complete Automatic Build E3.3.2.3 (2026-11-20)

- Main **Build SaberShader** now prepares compatible final-stage Endfield flags before the existing guarded AE Full Setup, including already-built verified AE scenes. This is a one-pass settings phase, **not a second material Build**.
- For authenticated single-actor AE only, fills **unset** flags for source ramps, hair, cloth, eyes/iris, live face, hair rim, highlight compression, AE color grading, AE silhouette, and reversible proxy/axes cleanup. Manually set flags and artist parameters are preserved; SOURCE fidelity preset skips additional material grading.
- New `ae_auto_profile_features` control enabled by default; respects the existing `ae129hf455_auto_full_setup` opt-out. The same source/actor ownership gate is used. If the Build cancels or throws, changed flags are rolled back; blocked/invalid projects are unchanged.
- Material & UV Audit runs as an optional diagnostic after verified AE builds and does not reassign shader materials. No forced render engine, lights, view transform, experimental hair previews, GN preview, LOD selection, Restore or Delete actions.
- Additional per-scene status telemetry in AE Full Setup panel.
- Shader graphs, VFX_B look, FX marker/restore and E3.3.2.2 repeat-Build guard unchanged. Any unresolved native Repeat Build failures remain unresolved until separately retested.
- Offline-only integration QA; not a Blender-native or visual equivalence certification.

## 1.0.4 — AE Si E3.3.2.2 (Repeat Build / VFX_B assignment fix)

- Corrects a **confirmed native Blender 5.1.1 regression**: a second Build
  reassigned all seven Si `vfxpart` meshes from the verified Dual Layer
  `VFX_B` material (29 nodes / 32 links) to `SaberShader - Mask.002`
  (2 nodes / 1 link). The initial build had passed.
- Protects only exact `S_actor_jsspsi_vfxpart_0[1-7]_lod0` objects with
  verified VFX_B / E3.3.1 / DefaultHGMaterial markers against the general
  source-name-to-canonical material reassignment.
- Excludes an exclusively owned VFX_B material from generic reconstruction,
  avoiding an unnecessary generic Mask clone for this source. Other uses of
  DefaultHGMaterial and other characters follow the previous Build.
- Changes **no** VFX nodes, look parameters, original textures, rig, or
  renderer settings. Restore operators are unchanged.
- New build signature detects mixed in-memory modules; restart Blender when
  installing. Offline regression: 151 inherited + 8 new guard cases passed.
- A repeat Build on actual Blender 5.1.1 with this patch is **not yet tested**.

# SaberShader 1.0.4 — Release notes

## 1.0.4 — Endfield readable labels & developer comments (E3.4.5.7, 2026-11-21)

- Replaces internal build-stage names in Endfield-facing panel labels, tooltips, operators and feedback with descriptive feature names. Developer tools remain hidden by default; no material tools are removed.
- Rewrites module documentation and adds `DEVELOPER_NOTES.md` with component responsibilities, source-verification constraints, repeat-Build protection, restoration rules and compatibility naming policy.
- Retains **all** registered `bl_idname` values, property and scene keys, node names, material tags and revision constants. Some historical identifiers will still appear to developers in the internal Shader Editor and diagnostic reports by design.
- Keeps the confirmed working eye-shadow UV-layer recovery, Si FX Build behavior, outline and color stages unmodified. Automated AST control-flow checks verify five critical modules against the previous package, ignoring only user-visible text and documentation.
- Offline checks: 91 unit tests passed; Python compilation and ZIP integrity verified. Blender 5.1.x native visual tests remain pending for this presentation-only update.



SaberShader offers shader profiles for General/MMD, Uma Musume, FGO Arcade,
Arknights: Endfield and other supported stylized characters.

## 1.0.4 — E3.4.5.1 Si automatic A after main Build (2026-11-21)

- Standard main **Build SaberShader** for a currently verified single Si actor now attempts the exact E3.4.1-style Single Trail **A** at the end of the existing pipeline, only on the seven original Si idle VFX LOD0 meshes. No automatic E341 A/B study, B variant, or E344 A2 adjustment is created.
- Preserves the pre-A material ID, reuses the *same* automatically staged A across repeat Builds by a guarded suspend/resume protocol, and includes explicit **Restore Pre-A Si VFX** and **Recover Suspended A** actions.
- Manual E341/E343/E344 sessions continue to block Build until restored; a current E341 manual A from the previous installation must be restored *once* before using the new main Build behavior. Direct guarded AE Full Setup refuses to overwrite active auto A.
- Independent and scoped to verified Si. Source-unknown, edited, shared, linked or incomplete states fail closed; no fallback material is invented. Updates the E345 QA workflow to use auto-Build A as the intended Si baseline.
- 15 simulated offline auto-A tests and 11 inherited E345 pure-logic fixtures pass; Blender 5.1.1 native output, visuals and actual cross-character runs remain pending.

## 1.0.4 — AE Si FX Validation integrated E3.3.2.1 (2026-11-20)

- Preserves the exact **E3.3.2 Dual Layer + Distortion shader**, values and stage/restore markers; no visual recalibration.
- Adds a read-only **Si VFX_B topology validation** after the existing verified AE Si main Build, scoped to the seven exact `vfxpart_0[1-7]` meshes.
- Detects missing/duplicate parts, absent mandatory texture nodes, stage/provenance mismatches and missing predecessor materials; permits approved detail/flow texture alternatives and Non-Color image copies.
- Stores a stable fingerprint at first valid Build and compares it with the next Build to assess idempotence; stored reference may be compared after reopening in a **new Blender session**. No implicit second Build or auto-save/reopen is performed.
- Checks that non-Si mesh/material states remain unchanged **during optional Si FX stages only**, not across the legacy AE Build.
- Adds **Validate Si FX E3.3.2 (Read Only)** to the AE Source Material Dictionary panel; exports an evidence JSON to a unique temporary file.
- Explicitly labels missing-image fault injection, staged Restore and cross-profile tests as `NOT TESTED` until separately executed in native Blender. No Blender-native testing is claimed here.
- Other AE actors, FGO, Uma and General routes remain untouched.

## 1.0.4 — AE Si VFX Dual Layer + Distortion E3.3.2 (experimental, 2026-11-20)

- Replaces the seven Si E3.3.1 procedural VFX preview graphs with Version B using real source-file texture identifiers (three mandatory maps, one optional mask).
- Integrated into the existing ONE-CLICK Build exclusively after a verified AE Build for exact Si meshes and provenance, with the same FK/IK-independent profile scope.
- Uses staged material copies and E3.3.x Restore; no source-material or geometry modification. Retains old E3.3.1 materials for conservative migration and single-step restoration.
- Idempotent for Version B; edited/unknown legacy E3.3.1 graphs are preserved. Required-image failures leave prior material slots intact and issue a nonfatal FX warning.
- Defaults to static UV mappings; no automatic drivers or animation. Source images are NOT bundled. No native Blender render fidelity assertion.

## 1.0.4 — AE Si FX Look Matching E3.3.1 (experimental, 2026-11-20)

- Supersedes E3.3 with **absolute opacity and emission targets** for the five exact Si FX materials, rather than stacking an extra factor on top of E3.1.
- Rebuilds the seven exact Si `vfxpart` previews with RGB-to-luminance mask feeding actual shader alpha, maximum preview alpha 0.12; this is an artistic hypothesis, not data from Unity.
- **Stages new material copies**, then atomically swaps their slots; on failure, attempts to roll back changes and source fake-user states.
- Adds **Restore Si FX Look E3.3.1**. Use this before earlier E3/E3.1/E3.2 restores. Older stage restore tools refuse active E3.3.1 look materials.
- Existing E3.3 materials with intact backups can be upgraded conservatively; edited/unknown values are preserved and skipped. Restoring E3.3.1 on such an older file returns it to the **previous E3.3 material**, not automatically to E3.1.
- Includes `ae_vfx_e32.py` in the module compatibility signature.
- Only runs after a verified AE build of Si. No changes to FGO, Uma, General, rigging, source geometry or textures.
- Offline tests only: **no native Blender 5.1.1 render equivalence claim**.

## 1.0.4 — AE Si FX Look Matching E3.3 (superseded)

- First non-transactional look preview. Replaced by E3.3.1 after review exposed its constant ramp alpha and stacked opacity multipliers.
- Older E3.3 materials may still exist in saved scenes. E3.3.1 detects their original marker and backup for conservative migration.

## 1.0.4 — AE Si VFX Translucent Preview E3.2 (experimental)

- Replaced incorrect opaque Hair preview on seven exact Si `DefaultHGMaterial` VFX meshes with an optional translucent preview (baseline 6% alpha).
- Original datablocks and restore operator preserved. The in-game appearance is unverified.

## 1.0.4 — AE FX Opacity & VFX Classification E3.1 (experimental)

- Post-E3 first opacity preview factor 0.25, applied only to unmodified E3 materials. Avoids stacking on repeat builds and offers restore.
- Classified seven exact Si VFX placeholders separately from ordinary hair material sources.

## 1.0.4 — AE Si FX Reconstruction E3 (experimental)

- Five exact-source Si FX material approximations using `_MainTex`, masks and distortion.
- No native Unity equations or guaranteed render equivalence; originals are preserved for restore.

## Reliability

- Add-on registration is transactional, with rollback if a registration step fails.
- Live Sync is disabled at startup and can be enabled explicitly from the sidebar.
- Scene activation does not automatically delete Line Art modifiers.
- Line Art diagnostic reports are read-only and export without overwriting files.
- The reference build refuses scenes with known Line Art risks rather than deleting modifiers.
- The **Rescan EyeHideAll** button refreshes morph bindings after importing a model;
  it can update shape-key values and supports Undo.
- Cache and event filtering avoid unnecessary work during dynamic updates.
- The module signature rejects mixed cached modules after an in-place upgrade.

## Upgrading

Disable the previous addon, close Blender, replace the installation, then start
Blender again. Never replace the package while it is registered in Blender.
Test with copies of existing `.blend` files before adopting a new package.

## Compatibility

Existing operator IDs, class IDs, Scene/Material properties, material and node
names, and stored metadata with historical revision suffixes remain intact.
Those identifiers are part of the data compatibility contract and should not
be renamed without an explicit, tested migration.

## Validation

This package is based on a functioning RC3 reported by the user. Its editorial
and structural changes were reviewed without native Blender execution in this
environment. Full scene-specific E2/E3 coverage for every profile is not implied.

## AE Source Material Dictionary — Si research E1 (2026-11-20)

- New exact-source JSON registry and read-only material connection audit in the
  Endfield panel, for the supplied Si (`jsspsi`) package only.
- No changes to `engine.py` or `ui.py`, no changes to any rendering algorithm,
  existing materials, UV maps, shaders or other profiles.
- FX materials are labelled separately because their Unity shader equations
  and packed channel mapping remain unverified.
- Requires native Blender 5.1.1 E2 testing; offline syntax and data tests do
  not validate in-Blender UI registration or render fidelity.

### AE One-Click Build + Si automatic source audit — E2 candidate

- Routes the main `Build SaberShader` button to the existing guarded AE Full
  Setup for a verified Endfield source, with no duplicate legacy Build.
- Preserves the existing pipelines for UMA/FGO/General, including Blender
  context and source-authorization safeguards.
- Runs the exact Si source-dictionary audit automatically **after a successful
  verified AE Build**, exporting a non-overwriting JSON report. Diagnostic
  failure is reported separately from an otherwise completed shader Build.
- Clarifies the 20 autogenerated Si expression-plane/outline slots as generated
  helpers, not unknown source materials.
- Removes the redundant AE-specific `Build + Apply AE Full Setup` button in
  favor of the single top-level Build; review/restore/optional settings remain.
- Bumps the in-process module signature including the two new AE modules to
  detect mixed cached module installations. Restart Blender when upgrading.
- No Unity FX equations have been inferred or installed. Existing material
  building algorithms were not changed; engine and lineart_tools were edited
  only to update their build signatures.


## E3.4.2 — AE Universal FX Foundation (read-only)

- Added `ae_fx_universal_core.py` (pure-source classification and exact Materials/Textures checks).
- Added `ae_fx_universal_e342.py` (verified single-actor FX audit and Endfield panel).
- Optional read-only source audit after verified AE Build for any canonical AE actor, with timestamped temp JSON.
- Preserves Si E3/E3.3.2 rendering and E3.4.1 A/B without modification; no cross-character auto-material conversion.
- Future E3.4.3/E3.4.4/E3.4.5 stages remain pending and require native validation.

### E3.4.4 — Si Idle Ink Fidelity Preset (opt-in)
- Added Si-only idle VFX A/A2 preset over the universal E3.4.3 parameter policy.
- Preserves A exactly, stages private A2 material and private nested Mask node group.
- Compatible with E3.4.1 parent experiment when Show A is active; child must restore first.
- No automatic application on Build; protects main and Full Setup entrypoints while active.
- 366/366 offline QA checks; requires Blender 5.1.1 native visual validation.


## E3.4.5.5 — EyeShadow UV Layer Recovery (2026-11-21)

- Fix AE123 Build requiring the **exact layer name** `UV0` even when a single
  existing UV map had another name; the original UV geometry is left intact.
- Source-mask graph now uses the resolved UV layer and validates the UVMap-to-image
  connection before marking the eyeshadow ready; keeps distinct owned materials
  for different UV layer names.
- Preserve conservative `NO_UV_LAYERS` / `AMBIGUOUS_UV_LAYERS` failures.
- Update AE124 status and the read-only Eye Build diagnostic with all UV layer names
  and the actual material, regardless of earlier missing-UV errors.
- No changes to non-AE profiles or to the Si FX A/A2 logic.
- Blender-native rendering and repeat-Build validation remain pending.
