# Third-party notices

SaberShader is an **independent community add-on**. It is not officially
affiliated with, endorsed by or sponsored by the publishers or rights holders
of games whose styles or asset naming conventions are supported.

Game titles, characters, material names, texture conventions and trademarks
belong to their respective rights holders. A profile name does not imply
affiliation or authorization to extract game resources.

This package does **not** include extracted game models, textures, animations or
third-party expression-eye images. Users must provide any optional resources
separately and only use files they own or have permission to use.

## Source-derived material metadata (Si / Arknights: Endfield)

`assets/AE_Si_Material_Source_Dictionary_V1.json` includes **source-derived
material metadata** transcribed from a user-supplied Si asset package: material
and texture identifiers, slot relationships, tint values, UV offsets/scales,
and selected source flags. It does **not** package the extracted game textures,
mesh files or Unity shader programs. That distinction does not establish that
the metadata is free of intellectual-property restrictions.

This file is used for research and compatibility matching. Third-party game
names, material definitions and associated rights remain with their respective
rights holders. Distributors are responsible for assessing whether reuse and
redistribution of the source-derived metadata is permitted in their context.
