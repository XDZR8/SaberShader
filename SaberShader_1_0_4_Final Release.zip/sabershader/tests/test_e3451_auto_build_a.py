"""Blender-free state and failure tests for E3.4.5.1 Build A.

Run: python sabershader/tests/test_e3451_auto_build_a.py
Mocks validate orchestration/invariants, not bpy, rendering or native FX.
"""
from __future__ import annotations
import importlib.util
from pathlib import Path
import sys
import types
import unittest

package = types.ModuleType('e3451_testpkg')
package.__path__ = []
ab = types.ModuleType('e3451_testpkg.ae_si_vfx_ab_e341')
ink = types.ModuleType('e3451_testpkg.ae_si_idle_ink_e344')
bpy = types.ModuleType('bpy')
bpy.types = types.SimpleNamespace(Operator=object)
for item in (package, ab, ink, bpy):
    sys.modules[item.__name__] = item


class ImageCollection(list):
    def get(self, name):
        return next((x for x in self if x.name == name), None)


class MatCollection(dict):
    def add(self, m):
        self[m.name] = m
    def remove(self, m):
        assert m.users == 0
        self.pop(m.name)


bpy.data = types.SimpleNamespace(materials=MatCollection(), images=ImageCollection())


class Material(dict):
    def __init__(self, name, graph='B', fake=False, exact=False, image=True, fail=False):
        super().__init__({'AEF_V11_SourceMaterial': 'DefaultHGMaterial'})
        self._name = name
        self.graph = graph
        self.use_fake_user = fake
        self.library = None
        self.override_library = None
        self.exact = exact
        self.has_image = image
        self.fail_stage = fail
        bpy.data.materials.add(self)

    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, name):
        bpy.data.materials.pop(self._name, None)
        self._name = name
        bpy.data.materials.add(self)
    @property
    def users(self):
        total = 1 if self.use_fake_user else 0
        for o in current.scene.objects:
            total += sum(1 for m in getattr(o.data, 'materials', []) if m is self)
        return total
    def copy(self):
        new = Material(self.name + '_copy', self.graph, fake=self.use_fake_user,
                       exact=self.exact, image=self.has_image, fail=self.fail_stage)
        new.update(self)
        return new


class Obj(dict):
    def __init__(self, name, material):
        super().__init__()
        self.name = name
        self.type = 'MESH'
        self.library = None
        self.override_library = None
        self.data = types.SimpleNamespace(materials=[material], library=None,
                                          override_library=None, users=1)


current = None


def objects(scene):
    return sorted((o for o in scene.objects if o.name.startswith('S_actor_jsspsi_vfxpart_')),
                  key=lambda x: x.name)


def require(ctx):
    seven = objects(ctx.scene)
    if len(seven) != 7 or any(o.get('manual') for o in seven):
        raise RuntimeError('manual comparison / incomplete Si')
    original = seven[0].data.materials[0]
    if any(o.data.materials[0] is not original for o in seven):
        raise RuntimeError('mixed baseline')
    return seven, original


ab._objects = objects
ab._require_objects = require
ab._readonly = lambda x: bool(x.library or x.override_library)
ab._material = lambda o: o.data.materials[0]
ab.has_active_comparison = lambda objs: any(o.get('manual') for o in objs)
ab._is_nested_mask_a = lambda m: m.exact
ab._find_main_image = lambda m: object() if m.has_image else None
ab._clear_inherited_stage_tags = lambda m: None

def make_a(m):
    if m.fail_stage:
        raise RuntimeError('deliberate shader construction failure')
    m.graph = 'A'
ab._single_trail_a = make_a
ink.has_active_comparison = lambda objs: any(o.get('manual344') for o in objs)
ink._graph_hash = lambda m: m.graph

path = Path(__file__).resolve().parents[1] / 'ae_si_build_a_e3451.py'
spec = importlib.util.spec_from_file_location('e3451_testpkg.ae_si_build_a_e3451', path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


class AutoABuildTest(unittest.TestCase):
    def setUp(self):
        global current
        bpy.data.materials.clear()
        bpy.data.images.clear()
        current = types.SimpleNamespace(scene=types.SimpleNamespace(objects=[]))
        self.original = Material('Source B')
        self.seven = [Obj(f'S_actor_jsspsi_vfxpart_{i:02d}_lod0', self.original)
                      for i in range(1, 8)]
        self.other = Obj('S_actor_wulfa_body_01_lod0', Material('Wulfa body'))
        current.scene.objects.extend(self.seven + [self.other])
        self.selection = list(self.seven)

    def create_a(self):
        r = module.apply_after_build(current, self.selection)
        self.assertEqual(r['status'], 'ACTIVE_A')
        return self.seven[0].data.materials[0]

    def test_single_click_applies_same_a_to_seven_and_not_wulfa(self):
        a = self.create_a()
        self.assertTrue(all(o.data.materials[0] is a for o in self.seven))
        self.assertEqual(a.graph, 'A')
        self.assertIs(self.other.data.materials[0], bpy.data.materials['Wulfa body'])
        self.assertTrue(self.original.use_fake_user)
        self.assertEqual(module.status(current), 'ACTIVE')

    def test_repeat_build_reuses_same_material_identity(self):
        a = self.create_a()
        start_names = set(bpy.data.materials)
        module.suspend_for_build(current, self.selection)
        self.assertTrue(all(o.data.materials[0] is self.original for o in self.seven))
        self.assertEqual(module.status(current), 'SUSPENDED')
        self.assertTrue(a.use_fake_user)
        module.resume_after_build(current, self.selection)
        self.assertTrue(all(o.data.materials[0] is a for o in self.seven))
        self.assertEqual(start_names, set(bpy.data.materials))
        self.assertFalse(a.use_fake_user)
        self.assertEqual(module.status(current), 'ACTIVE')

    def test_restore_precise_original_and_clear_tags(self):
        a = self.create_a()
        result = module.restore_original(current, self.selection)
        self.assertEqual(result['status'], 'ORIGINAL_RESTORED')
        self.assertTrue(all(o.data.materials[0] is self.original for o in self.seven))
        self.assertNotIn(a.name, bpy.data.materials)
        self.assertFalse(self.original.use_fake_user)
        self.assertEqual(module.status(current), 'NONE')

    def test_restore_preserves_preexisting_original_fake_user(self):
        self.original.use_fake_user = True
        self.create_a()
        module.restore_original(current, self.selection)
        self.assertTrue(self.original.use_fake_user)

    def test_missing_one_selected_mesh_fails_without_changes(self):
        with self.assertRaisesRegex(RuntimeError, 'all seven'):
            module.apply_after_build(current, self.selection[:-1])
        self.assertTrue(all(o.data.materials[0] is self.original for o in self.seven))

    def test_manual_comparison_remains_guarded(self):
        self.seven[0]['manual'] = True
        with self.assertRaisesRegex(RuntimeError, 'Manual'):
            module.apply_after_build(current, self.selection)
        self.seven[0].pop('manual')
        self.seven[0]['manual344'] = True
        with self.assertRaisesRegex(RuntimeError, 'Manual'):
            module.apply_after_build(current, self.selection)

    def test_missing_image_skips_without_changes(self):
        self.original.has_image = False
        self.assertEqual(module.apply_after_build(current, self.selection)['status'],
                         'SKIPPED_GFX18_UNAVAILABLE')
        self.assertEqual(set(bpy.data.materials), {'Source B', 'Wulfa body'})

    def test_existing_exact_a_is_not_copied(self):
        self.original.exact = True
        self.assertEqual(module.apply_after_build(current, self.selection)['status'], 'ALREADY_EXACT_A')
        self.assertTrue(all(o.data.materials[0] is self.original for o in self.seven))

    def test_mutated_a_fails_closed_on_next_build(self):
        a = self.create_a()
        a.graph = 'ARTIST_MODIFIED'
        with self.assertRaisesRegex(RuntimeError, 'material changed'):
            module.suspend_for_build(current, self.selection)
        self.assertEqual(module.status(current), 'ACTIVE')

    def test_edited_baseline_fails_closed_on_repeat_build(self):
        self.create_a()
        self.original.graph = 'ARTIST_CHANGED_BASELINE'
        with self.assertRaisesRegex(RuntimeError, 'material changed'):
            module.suspend_for_build(current, self.selection)

    def test_shared_source_baseline_is_rejected_before_apply(self):
        current.scene.objects.append(Obj('S_actor_other_random_lod0', self.original))
        with self.assertRaisesRegex(RuntimeError, 'shared with another mesh'):
            module.apply_after_build(current, self.selection)
        self.assertEqual(module.status(current), 'NONE')

    def test_foreign_use_of_auto_a_fails_closed(self):
        a = self.create_a()
        outsider = Obj('S_actor_wulfa_extra_lod0', a)
        current.scene.objects.append(outsider)
        with self.assertRaisesRegex(RuntimeError, 'untracked'):
            module.suspend_for_build(current, self.selection)
        self.assertIs(outsider.data.materials[0], a)

    def test_shader_constructor_error_rolls_back(self):
        self.original.fail_stage = True
        with self.assertRaisesRegex(RuntimeError, 'deliberate'):
            module.apply_after_build(current, self.selection)
        self.assertTrue(all(o.data.materials[0] is self.original for o in self.seven))
        self.assertEqual(set(bpy.data.materials), {'Source B', 'Wulfa body'})
        self.assertFalse(self.original.use_fake_user)

    def test_partial_session_is_not_silently_reused(self):
        self.create_a()
        self.seven[1].pop(module.TOKEN)
        self.assertEqual(module.status(current), 'INCOMPLETE')
        with self.assertRaisesRegex(RuntimeError, 'Incomplete'):
            module.suspend_for_build(current, self.selection)

    def test_changed_slot_fails_closed(self):
        self.create_a()
        self.seven[0].data.materials[0] = self.original
        with self.assertRaisesRegex(RuntimeError, 'assignment changed'):
            module.suspend_for_build(current, self.selection)


if __name__ == '__main__':
    unittest.main()
