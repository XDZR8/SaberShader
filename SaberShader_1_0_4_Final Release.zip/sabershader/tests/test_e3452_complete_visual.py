"""Mocked E3.4.5.2 execution gate, AE visuals and rollback tests.

These are Blender-free state-machine tests, not rendered scene verification.
"""
import importlib.util
import sys
import types
from pathlib import Path
import unittest

pkg = types.ModuleType('e3452_testpkg')
pkg.__path__ = []
engine = types.ModuleType('e3452_testpkg.engine')
engine._AE126_VIEW = 'Khronos PBR Neutral'
engine.verified = True
engine.owner = 'READY'
engine._xdzr8_ae129hf455_is_verified = lambda info: bool(info.get('verified')) and engine.verified
engine._xdzr8_ae129hf455_is_wulfa = lambda info: bool(info.get('wulfa', False))
engine._xdzr8_ae_fullsetup_owner_check = lambda scene, info, objs: {'status':engine.owner}
engine._xdzr8_ae126_capture_cm = lambda scene: dict(scene.cm)

def color_apply(scene):
    if scene.fail_color:
        raise ValueError('View transform not available')
    if not scene.get('_prior_cm'):
        scene['_prior_cm'] = dict(scene.cm)
    scene.cm.update(display_device='sRGB', view_transform=engine._AE126_VIEW,
                    look='None', exposure=0.0, gamma=1.0)
    return dict(scene.cm)

engine._xdzr8_ae126_apply_cm = color_apply
sys.modules[pkg.__name__] = pkg
sys.modules[engine.__name__] = engine

base = Path(__file__).resolve().parents[1]
def load(name):
    qual = pkg.__name__ + '.' + name
    spec = importlib.util.spec_from_file_location(qual, base / (name + '.py'))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[qual] = mod
    spec.loader.exec_module(mod)
    return mod

profile = load('ae_auto_profile')
visual = load('ae_full_visual_e3452')


class Settings:
    def __init__(self, enabled=True, preset='BALANCED', **params):
        self._assigned = set(params)
        self.ae_auto_profile_features = enabled
        self.ae123_fidelity_preset = preset
        for flag in profile.DEFAULT_FINAL_FLAGS + profile.WULFA_FINAL_FLAGS:
            setattr(self, flag, params.get(flag, False))
        for key, desired in profile.FINAL_VIEW_ENUMS:
            setattr(self, key, params.get(key, desired))
    def is_property_set(self, key):
        return key in self._assigned
    def property_unset(self, key):
        setattr(self, key, False)
        self._assigned.discard(key)

class Scene(dict):
    def __init__(self):
        super().__init__()
        self.cm = {'display_device':'sRGB', 'view_transform':'AgX',
                   'look':'Medium High Contrast', 'exposure':0.0, 'gamma':1.0}
        self.fail_color = False

class TestCompleteVisual(unittest.TestCase):
    def setUp(self):
        engine.verified = True
        engine.owner = 'READY'
        self.scene = Scene()
        self.settings = Settings(ae_outline_enabled=False, ae123_eye_full_setup=False,
                                 ae126_grade_enabled=False)
        self.info = {'verified':True}
        self.objects = ['exact actor']
        self.ctx = types.SimpleNamespace(scene=self.scene)

    def prepare(self):
        return profile.prepare(self.scene, self.settings, self.info, self.objects)
    def finish(self, result):
        return visual.complete_post_build(self.ctx, self.settings, self.info, self.objects,
                                          result, verified_after=True)

    def test_forces_explicitly_off_final_flags_in_old_blend(self):
        result = self.prepare()
        self.assertEqual(result['status'], 'CONFIGURED')
        self.assertIn('ae_outline_enabled', result['overridden'])
        self.assertIn('ae123_eye_full_setup', result['overridden'])
        self.assertIn('ae126_grade_enabled', result['overridden'])
        self.assertTrue(all(getattr(self.settings, k) for k in profile.DEFAULT_FINAL_FLAGS))

    def test_wulfa_hf2_is_source_scoped(self):
        self.info['wulfa'] = True
        self.assertEqual(self.prepare()['status'], 'CONFIGURED')
        self.assertTrue(self.settings.ae129hf2_enabled)
        self.assertTrue(self.settings.ae129hf454_hf2_auto_recovery)
        other = Settings()
        self.info['wulfa'] = False
        profile.prepare(self.scene, other, self.info, self.objects)
        self.assertFalse(other.ae129hf2_enabled)

    def test_complete_build_returns_debug_modes_to_final(self):
        self.settings.ae129hf451_face_mode = 'SDF'
        self.settings.ae129hf45_preview = 'RIM_ONLY'
        self.settings._assigned.update({'ae129hf451_face_mode','ae129hf45_preview'})
        r = self.prepare()
        self.assertEqual(self.settings.ae129hf451_face_mode, 'SCENE')
        self.assertEqual(self.settings.ae129hf45_preview, 'FINAL')
        self.assertIn('ae129hf45_preview', r['overridden'])
        profile.rollback(self.settings, r)
        self.assertEqual(self.settings.ae129hf451_face_mode, 'SDF')
        self.assertEqual(self.settings.ae129hf45_preview, 'RIM_ONLY')

    def test_rollback_restores_explicit_off_and_unset(self):
        result = self.prepare()
        self.assertTrue(self.settings.ae_outline_enabled)
        profile.rollback(self.settings, result)
        self.assertFalse(self.settings.ae_outline_enabled)
        self.assertTrue(self.settings.is_property_set('ae_outline_enabled'))
        self.assertFalse(self.settings.ae_hair_enabled)
        self.assertFalse(self.settings.is_property_set('ae_hair_enabled'))

    def test_source_preset_excludes_style_but_keeps_outline_and_eyes(self):
        self.settings.ae123_fidelity_preset = 'SOURCE'
        result = self.prepare()
        self.assertFalse(self.settings.ae126_grade_enabled)
        self.assertFalse(self.settings.ae_shading_enabled)
        self.assertTrue(self.settings.ae_outline_enabled)
        self.assertTrue(self.settings.ae123_eye_full_setup)
        self.assertIn(('ae126_grade_enabled','SOURCE_PRESET_PRESERVED'), result['skipped'])

    def test_no_preflight_no_changes(self):
        engine.owner = 'BLOCKED_OTHER_ACTOR'
        result = self.prepare()
        self.assertEqual(result['status'], 'BLOCKED_OTHER_ACTOR')
        self.assertFalse(self.settings.ae_outline_enabled)
        self.assertEqual(self.finish(result)['status'], 'SKIPPED_PREFLIGHT')
        self.assertEqual(self.scene.cm['view_transform'], 'AgX')

    def test_unverified_never_changes_stage_or_scene_color(self):
        engine.verified = False
        result = self.prepare()
        self.assertEqual(result['status'], 'SKIP_UNVERIFIED')
        self.assertFalse(self.settings.ae_outline_enabled)
        self.assertEqual(self.finish(result)['status'], 'SKIPPED_UNVERIFIED')
        self.assertEqual(self.scene.cm['view_transform'], 'AgX')

    def test_master_opt_out_keeps_existing_flags(self):
        self.settings.ae_auto_profile_features = False
        result = self.prepare()
        self.assertEqual(result['status'], 'DISABLED')
        self.assertFalse(self.settings.ae_outline_enabled)
        self.assertEqual(self.finish(result)['status'], 'DISABLED_BY_USER')

    def test_color_view_applied_and_restore_snapshot_preserved(self):
        self.scene['SaberShader_AE110_ShellCount'] = 8
        self.scene['SaberShader_AE123_EyeOverlays'] = 1
        result = self.prepare()
        first = self.finish(result)
        self.assertEqual(first['status'], 'COMPLETE')
        self.assertEqual(first['outline'], 'APPLIED_8_SHELLS')
        self.assertEqual(first['eyeshadow'], 'APPLIED_1_OVERLAYS')
        self.assertEqual(first['color'], 'APPLIED_PBR_NEUTRAL')
        self.assertEqual(self.scene['_prior_cm']['view_transform'], 'AgX')
        second = self.finish(result)
        self.assertEqual(second['color'], 'ALREADY_PBR_NEUTRAL')
        self.assertEqual(self.scene['_prior_cm']['view_transform'], 'AgX')

    def test_missing_eyeshadow_source_not_marked_complete(self):
        self.scene['SaberShader_AE110_ShellCount'] = 3
        result = self.prepare()
        run = self.finish(result)
        self.assertEqual(run['status'], 'PARTIAL')
        self.assertEqual(run['eyeshadow'], 'CHECK_EYE_REPORT')
        self.assertEqual(run['color'], 'APPLIED_PBR_NEUTRAL')

    def test_no_outline_mesh_not_marked_complete(self):
        self.scene['SaberShader_AE123_EyeOverlays'] = 1
        result = self.prepare()
        run = self.finish(result)
        self.assertEqual(run['status'], 'PARTIAL')
        self.assertEqual(run['outline'], 'NO_ELIGIBLE_SHELLS')

    def test_repeat_eye_overlay_verified_without_new_assignment(self):
        # A repeated native AE123 Build can report 0 *new* overlays while
        # retaining the output-connected, source-verified previous overlay.
        self.scene['SaberShader_AE110_ShellCount'] = 4
        self.scene['SaberShader_AE123_EyeOverlays'] = 0
        mesh = types.SimpleNamespace(type='MESH', name='S_actor_foo_eyeshadow_01_lod0',
                                     hide_render=False,
                                     material_slots=[types.SimpleNamespace(material='valid')])
        self.scene.objects = [mesh]
        original = (getattr(engine, '_xdzr8_ae119_source_files', None),
                    getattr(engine, '_xdzr8_ae120_parse_eye', None),
                    getattr(engine, '_xdzr8_ae125_overlay_graph', None),
                    engine._xdzr8_ae_fullsetup_owner_check)
        try:
            engine._xdzr8_ae119_source_files = lambda settings: ({'png':'exact'},'')
            engine._xdzr8_ae120_parse_eye = lambda name: {'actor':'foo', 'part':'eyeshadow', 'lod':0}
            engine._xdzr8_ae125_overlay_graph = lambda mat, source: (mat == 'valid', '')
            engine._xdzr8_ae_fullsetup_owner_check = lambda scene, info, objs: {'status':'READY','actor':'foo'}
            result = self.prepare()
            run = self.finish(result)
            self.assertEqual(run['status'], 'COMPLETE')
            self.assertEqual(run['eyeshadow'], 'PRESERVED_VERIFIED_OVERLAY')
        finally:
            a,b,c,d = original
            for name, old in (('_xdzr8_ae119_source_files',a),
                              ('_xdzr8_ae120_parse_eye',b),('_xdzr8_ae125_overlay_graph',c)):
                if old is None: delattr(engine,name)
                else: setattr(engine,name,old)
            engine._xdzr8_ae_fullsetup_owner_check = d

    def test_one_click_does_not_automatically_call_manual_qa_ops(self):
        text = (base / 'ae_one_click.py').read_text()
        self.assertNotIn('bpy.ops.sabershader.ae113_fidelity_uv_audit', text)
        self.assertNotIn('_universalfx.inspect_after_build(', text)
        self.assertNotIn('audit = source_audit_after_build(', text)
        self.assertEqual(text.count("bpy.ops.sabershader.ae_fullsetup_safe_build('EXEC_DEFAULT')"),1)

    def test_ocios_missing_rolls_back_color_and_warns(self):
        result = self.prepare()
        self.scene.fail_color = True
        run = self.finish(result)
        self.assertEqual(run['status'], 'PARTIAL')
        self.assertEqual(run['color'], 'ERROR_COLOR_VIEW')
        self.assertEqual(self.scene.cm['view_transform'], 'AgX')

    def test_zero_delta_second_build_is_configured(self):
        first = self.prepare()
        self.assertEqual(first['status'], 'CONFIGURED')
        second = self.prepare()
        self.assertEqual(second['status'], 'ALREADY_CONFIGURED')
        self.assertEqual(second['changed'], [])

    def test_eyes_only_lod_guard_not_claimed_as_overlay(self):
        self.scene['SaberShader_AE110_ShellCount'] = 2
        self.scene['SaberShader_AE123_GuardedLODs'] = 4
        run = self.finish(self.prepare())
        self.assertEqual(run['eyeshadow'], 'LOD_GUARD_ONLY_4')

    def test_scene_color_not_applied_to_failed_build(self):
        result = self.prepare()
        run = visual.complete_post_build(self.ctx, self.settings, self.info,
                                         self.objects, result, verified_after=False)
        self.assertEqual(run['status'], 'SKIPPED_UNVERIFIED')
        self.assertEqual(self.scene.cm['view_transform'], 'AgX')

if __name__ == '__main__':
    unittest.main()
