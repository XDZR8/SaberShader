"""Mock-only regression tests for E3.4.5.3. Blender rendering remains untested."""
import importlib.util
from pathlib import Path
import sys
import types
import unittest

package = types.ModuleType('e3453_fake_pkg')
package.__path__ = []
engine = types.ModuleType('e3453_fake_pkg.engine')
sys.modules[package.__name__] = package
sys.modules[engine.__name__] = engine

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(package.__name__ + '.ae_eye_build_e3453',
                                             ROOT / 'ae_eye_build_e3453.py')
eye = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = eye
spec.loader.exec_module(eye)

class Material(dict):
    def __init__(self, valid=False):
        super().__init__()
        self.valid = valid

class Mesh:
    def __init__(self):
        self.uv_layers = {'UV0': object()}

class Object(dict):
    def __init__(self, name='S_actor_lizhiyan_eyeshadow_01_lod0'):
        super().__init__()
        self.name = name
        self.type = 'MESH'
        self.hide_render = False
        self.hidden = False
        self.data = Mesh()
        self.material_slots = [types.SimpleNamespace(material=Material())]

class Scene(dict):
    def __init__(self, objs):
        super().__init__()
        self.objects = objs

class TestE3453(unittest.TestCase):
    def setUp(self):
        self.obj = Object()
        self.scene = Scene([self.obj])
        self.context = types.SimpleNamespace(scene=self.scene)
        self.settings = types.SimpleNamespace(ae_auto_profile_features=True,
                                              ae123_eye_full_setup=True)
        self.info = {'verified': True}
        self.objects = [self.obj]
        self.autoae = {'status': 'CONFIGURED'}
        self.owner = 'READY'
        self.source = {'png': '/verified/Textures/T_actor_common_eyeshadow_01_M.png'}
        self.reason = ''
        self.actor = 'lizhiyan'
        self.called = 0
        self.repair = True
        self.manual_preserved = False
        self.throw = False
        engine._xdzr8_ae129hf455_is_verified = lambda info: info.get('verified', False)
        engine._xdzr8_ae_fullsetup_owner_check = lambda _scene, _info, _objects: {'status': self.owner}
        engine._xdzr8_ae123_actor = lambda *_args: (self.actor, self.reason)
        engine._xdzr8_ae119_source_files = lambda _settings: (self.source, self.reason)
        engine._xdzr8_ae120_parse_eye = lambda name: (
            {'actor':'lizhiyan', 'part':'eyeshadow', 'lod':0}
            if name.startswith('S_actor_lizhiyan_eyeshadow_01_lod0') else None)
        engine._xdzr8_ae120_is_hidden = lambda obj: obj.hidden
        engine._xdzr8_ae125_overlay_graph = lambda mat, _src: (mat.valid,
                            'OK_SOURCE_MASK_TO_SURFACE' if mat.valid else 'SOURCE_MASK_NOT_CONNECTED')
        def repair(*_args):
            self.called += 1
            if self.throw:
                raise RuntimeError('intentional test failure')
            if self.repair and not self.manual_preserved:
                self.obj.material_slots[0].material = Material(valid=True)
                return {'status':'VERIFIED','overlays':1,'notes':['AUTO EYESHADOW']}
            return {'status':'VERIFIED','overlays':0,'notes':['KEEP PRESERVE_CUSTOM_MANUAL']}
        engine._xdzr8_ae123_eye_full_setup = repair

    def run_stage(self):
        return eye.ensure_eye_overlay(self.context, self.settings, self.info,
                                      self.objects, self.autoae, True)

    def test_already_ready_no_double_stage(self):
        self.obj.material_slots[0].material.valid = True
        result = self.run_stage()
        self.assertEqual(result['status'], 'ALREADY_READY')
        self.assertEqual(self.called, 0)
        self.assertTrue(result['ready'])

    def test_missing_mask_repaired_once_with_original_ae123(self):
        result = self.run_stage()
        self.assertEqual(result['status'], 'REPAIRED')
        self.assertEqual(result['repaired'], 1)
        self.assertEqual(self.called, 1)
        self.assertEqual(self.run_stage()['status'], 'ALREADY_READY')
        self.assertEqual(self.called, 1)

    def test_missing_json_png_fails_closed(self):
        self.source, self.reason = None, 'Exact EyeShadow JSON and PNG not found'
        result = self.run_stage()
        self.assertEqual(result['status'], 'BLOCKED_MISSING_MASK')
        self.assertIn('JSON and PNG', result['detail'])
        self.assertEqual(self.called, 0)

    def test_unverified_ae_no_repair(self):
        self.info['verified'] = False
        self.assertEqual(self.run_stage()['status'], 'SKIPPED_UNVERIFIED')
        self.assertEqual(self.called, 0)

    def test_scene_authorization_gate_no_repair(self):
        out = eye.ensure_eye_overlay(self.context, self.settings, self.info,
                                     self.objects, self.autoae, False)
        self.assertEqual(out['status'], 'SKIPPED_UNVERIFIED')
        self.assertEqual(self.called, 0)

    def test_owner_preflight_no_repair(self):
        self.owner = 'BLOCKED_OTHER_ACTOR'
        self.assertEqual(self.run_stage()['status'], 'BLOCKED_OWNER')
        self.assertEqual(self.called, 0)

    def test_actor_provenance_no_repair(self):
        self.actor, self.reason = '', 'original iris JSON missing'
        self.assertEqual(self.run_stage()['status'], 'BLOCKED_ACTOR_SOURCE')
        self.assertEqual(self.called, 0)

    def test_ambiguous_lod0_does_not_guess(self):
        self.scene.objects.append(Object())
        self.assertEqual(self.run_stage()['status'], 'BLOCKED_EYESHADOW_LOD0')
        self.assertEqual(self.called, 0)

    def test_disabled_auto_profile_no_repair(self):
        self.settings.ae_auto_profile_features = False
        self.assertEqual(self.run_stage()['status'], 'DISABLED_BY_USER')
        self.assertEqual(self.called, 0)

    def test_disabled_eye_stage_no_repair(self):
        self.settings.ae123_eye_full_setup = False
        self.assertEqual(self.run_stage()['status'], 'DISABLED_EYE_SETUP')
        self.assertEqual(self.called, 0)

    def test_lod0_hidden_does_not_claim_success(self):
        self.obj.hidden = True
        result = self.run_stage()
        self.assertEqual(result['status'], 'NEEDS_ATTENTION')
        self.assertEqual(self.called, 1)
        self.assertFalse(result['ready'])

    def test_manual_assignment_preserved(self):
        self.manual_preserved = True
        before = self.obj.material_slots[0].material
        result = self.run_stage()
        self.assertEqual(result['status'], 'NEEDS_ATTENTION')
        self.assertIs(self.obj.material_slots[0].material, before)
        self.assertIn('PRESERVE_CUSTOM_MANUAL', result['detail'])

    def test_backend_failure_never_claims_complete(self):
        self.throw = True
        result = self.run_stage()
        self.assertEqual(result['status'], 'ERROR_SAFE')
        self.assertFalse(result['ready'])

    def test_bad_uv0_never_counts_ready(self):
        self.obj.data.uv_layers.clear()
        result = self.run_stage()
        self.assertEqual(result['status'], 'NEEDS_ATTENTION')
        self.assertIn('MISSING_UV0', result['detail'])

    def test_settings_not_prepared_no_repair(self):
        self.autoae = {'status': 'SKIPPED'}
        self.assertEqual(self.run_stage()['status'], 'SKIPPED_PREFLIGHT')
        self.assertEqual(self.called, 0)

if __name__ == '__main__':
    unittest.main()
