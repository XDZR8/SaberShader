"""Offline E3454 tests. Blender-native integration and render checks are pending."""
import importlib.util
import json
from pathlib import Path
import sys
import types
import unittest

package = types.ModuleType('e3454_mock')
package.__path__ = []
sys.modules[package.__name__] = package
bpy = types.ModuleType('bpy')
bpy.types = types.SimpleNamespace(Operator=object)
sys.modules['bpy'] = bpy
engine = types.ModuleType('e3454_mock.engine')
sys.modules[engine.__name__] = engine
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location(package.__name__ + '.ae_eye_build_e3454', ROOT / 'ae_eye_build_e3454.py')
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

class Mat(dict):
    def __init__(self, name='SaberShader - Eyes', valid=False):
        super().__init__()
        self.name = name
        self.valid = valid

class Mesh:
    def __init__(self, users=2):
        self.uv_layers = {'UV0': True}
        self.users = users

class Obj(dict):
    def __init__(self, name='S_actor_lizhiyan_eyeshadow_01_lod0', users=2):
        super().__init__()
        self.name = name
        self.type = 'MESH'
        self.hide_render = False
        self.data = Mesh(users)
        self.material_slots = [types.SimpleNamespace(material=Mat(), link='DATA')]

class Ctx:
    def __init__(self, objects):
        self.scene = types.SimpleNamespace()  # overwritten
        self.scene = Scene(objects)
        self.active_object = objects[0] if objects else None

class Scene(dict):
    def __init__(self, objects):
        super().__init__()
        self.objects = objects

class TestRecovery(unittest.TestCase):
    def setUp(self):
        self.obj = Obj()
        self.ctx = Ctx([self.obj])
        self.scene = self.ctx.scene
        self.scene['SaberShader_AEStateV1_EffectiveSourceFolder'] = '/valid/Si/Textures'
        self.scene['SaberShader_AEStateV1_ActorId'] = 'lizhiyan'
        self.settings = types.SimpleNamespace(universal_texture_folder='/wrong/folder',
                                              ae_auto_profile_features=True,
                                              ae123_eye_full_setup=True)
        self.scene.aef_sabershader_v8 = self.settings
        self.calls = []
        self.info = {'endfield_profile': {'enabled': True}}
        self.actors = [self.obj]
        self.autoae = {'status': 'CONFIGURED'}
        engine._xdzr8_ae129hf455_is_verified = lambda info: bool(info.get('endfield_profile', {}).get('enabled'))
        engine._xdzr8_ae_fullsetup_owner_check = lambda _scene, _info, _objects: {'status': 'READY','actor':'lizhiyan'}
        engine._xdzr8_ae120_source_proof = lambda settings, actor: 'iris JSON' if actor == 'lizhiyan' and '/valid/' in settings.universal_texture_folder else ''
        engine._xdzr8_ae119_source_files = lambda settings: (
            ({'png': '/valid/Si/Textures/eyeshadow.png','json':'/valid/Si/Materials/eyeshadow.json'}, '')
            if '/valid/' in settings.universal_texture_folder else (None,'missing source mask'))
        engine._xdzr8_ae123_actor = lambda _context, settings, *_args: (
            'lizhiyan','') if '/valid/' in settings.universal_texture_folder else ('','no iris')
        engine._xdzr8_ae120_parse_eye = lambda name: (
            {'actor':'lizhiyan','part':'eyeshadow','lod':0,'variant':'01'}
            if name.casefold().startswith('s_actor_lizhiyan_eyeshadow_01_lod0') else None)
        engine._xdzr8_ae120_is_hidden = lambda obj: False
        engine._xdzr8_ae125_overlay_graph = lambda mat, source: (mat.valid, 'OK_SOURCE_MASK_TO_SURFACE' if mat.valid else 'NOT_AE119_OVERLAY')
        engine._xdzr8_ae123_eye_uv_layer = lambda obj: ('UV0', 'EXACT_UV0') if obj.data.uv_layers.get('UV0') else ('', 'NO_UV_LAYERS')
        engine._xdzr8_ae125_overlay_uv_correct = lambda mat, uv: mat.valid and uv == 'UV0'
        engine._AE119_ORIGINAL = 'manual'
        engine._AE122_STATE = 'eye122'
        engine._AE123_EYE_STATE = 'ae123'
        def repair(_ctx, settings, _objects, _info):
            self.calls.append(settings.universal_texture_folder)
            self.obj.material_slots[0].link='OBJECT'
            self.obj.material_slots[0].material = Mat('SaberShader AE | Eye Shadow Overlay | lizhiyan', True)
            return {'status': 'VERIFIED', 'overlays':1, 'notes':['AUTO EYESHADOW']}
        engine._xdzr8_ae123_eye_full_setup = repair

    def run_stage(self):
        return mod.ensure_eye_overlay(self.ctx,self.settings,self.info,self.actors,self.autoae,True)

    def test_recovered_effective_folder_used_after_build(self):
        result = self.run_stage()
        self.assertEqual(result['status'], 'REPAIRED')
        self.assertEqual(result['source_mode'], 'BUILD_EFFECTIVE')
        self.assertEqual(self.calls, ['/valid/Si/Textures'])
        self.assertEqual(self.settings.universal_texture_folder, '/wrong/folder')
        self.assertEqual(self.obj.data.users, 2)
        self.assertEqual(self.obj.material_slots[0].link,'OBJECT')

    def test_repeat_build_idempotent(self):
        self.run_stage()
        second = self.run_stage()
        self.assertEqual(second['status'],'ALREADY_READY')
        self.assertEqual(len(self.calls),1)

    def test_configured_source_preferred(self):
        self.settings.universal_texture_folder = '/valid/Si'
        self.assertEqual(self.run_stage()['source_mode'], 'CONFIGURED')

    def test_source_fails_closed(self):
        self.scene['SaberShader_AEStateV1_EffectiveSourceFolder'] = ''
        result = self.run_stage()
        self.assertEqual(result['status'],'BLOCKED_SOURCE_FILES')
        self.assertIn('matching actor iris JSON',result['detail'])
        self.assertFalse(self.calls)

    def test_unverified_does_not_modify(self):
        result = mod.ensure_eye_overlay(self.ctx,self.settings,self.info,self.actors,self.autoae,False)
        self.assertEqual(result['status'],'SKIPPED_UNVERIFIED')
        self.assertFalse(self.calls)

    def test_second_actor_is_blocked(self):
        self.ctx.scene.objects.append(Obj())
        result = self.run_stage()
        self.assertEqual(result['status'],'BLOCKED_EYESHADOW_LOD0')
        self.assertFalse(self.calls)

    def test_manual_off_is_honored(self):
        self.settings.ae_auto_profile_features=False
        self.assertEqual(self.run_stage()['status'],'DISABLED_BY_USER')
        self.assertFalse(self.calls)

    def test_read_only_diagnostic_shows_actual_slot(self):
        before = self.obj.material_slots[0].material
        data = mod.inspect(self.ctx)
        self.assertEqual(data['source_mode'],'BUILD_EFFECTIVE')
        self.assertEqual(data['objects'][0]['material'],'SaberShader - Eyes')
        self.assertEqual(data['objects'][0]['mesh_users'],2)
        self.assertFalse(data['objects'][0]['graph_valid'])
        self.assertIs(self.obj.material_slots[0].material, before)

    def test_wrong_actor_source_is_not_accepted(self):
        engine._xdzr8_ae120_source_proof = lambda *_args: ''
        self.assertEqual(self.run_stage()['status'], 'BLOCKED_SOURCE_FILES')
        self.assertFalse(self.calls)

    def test_exception_captured_without_false_success(self):
        engine._xdzr8_ae123_eye_full_setup = lambda *_: (_ for _ in ()).throw(RuntimeError('fail'))
        self.assertEqual(self.run_stage()['status'],'ERROR_SAFE')
        self.assertFalse(self.scene.get(mod._PREFIX+'Status') == 'REPAIRED')

if __name__ == '__main__': unittest.main()
