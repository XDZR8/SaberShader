"""Offline E3.4.5.5 UV resolver + AE123 integrated setup tests.

These run the actual Python function bodies extracted from engine.py, with a
minimal bpy-independent test scene. Render validation must occur in Blender.
"""
import ast
import json
from pathlib import Path
import types
import unittest

source = Path(__file__).resolve().parents[1].joinpath('engine.py').read_text(encoding='utf-8')
module = ast.parse(source)
needed = {'_xdzr8_ae123_eye_uv_layer', '_xdzr8_ae123_eye_full_setup',
          '_xdzr8_ae125_overlay_uv_correct'}
funcs = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in needed]
assert len(funcs) == len(needed)
ns = {'json':json}
exec(compile(ast.Module(body=funcs, type_ignores=[]), '<engine extracted>', 'exec'), ns)

class Layer:
    def __init__(self,name): self.name=name
class Layers(list):
    def get(self,name): return next((x for x in self if x.name==name), None)
class Material(dict):
    def __init__(self, name, overlay=False):
        super().__init__();self.name=name;self['owned']=overlay
    def get(self,k,default=None):return super().get(k,default)
class Obj(dict):
    def __init__(self,name,layers):
        super().__init__();self.name=name;self.type='MESH';self.data=types.SimpleNamespace(uv_layers=Layers(map(Layer,layers)))
        self.library=None;self.hide_render=False
        self.material_slots=[types.SimpleNamespace(material=Material('SaberShader - Eyes'),link='DATA')]
class Ctx:
    def __init__(self, objects): self.scene=types.SimpleNamespace(objects=objects)

# Attach engine policy/source hooks needed for core function.
ns.update({
    '_xdzr8_ae123_actor': lambda context,settings,objects,info: ('lizhiyan',''),
    '_xdzr8_ae119_source_files': lambda settings: ({'png':'/valid/mask.png','color':(1,1,1)},''),
    '_xdzr8_ae120_parse_eye': lambda name: (
        {'actor':'lizhiyan','part':('iris' if 'iris' in name else 'eyeshadow'),'variant':'01','lod':0}
        if name.startswith('S_actor_lizhiyan_') else None),
    '_xdzr8_ae120_is_hidden': lambda obj: False,
    '_xdzr8_ae124_recover_legacy_eyeshadow': lambda *_: False,
    '_xdzr8_ae125_manual_eye_policy': lambda obj,mat,source,uv: 'NONE',
    '_xdzr8_ae125_overlay_graph': lambda mat,source: (bool(mat.get('owned')), 'OK' if mat.get('owned') else 'NOT_OVERLAY'),
    '_AE111_TAG':'cleanup','_AE119_LOD_STATE':'ae119_lod',
    '_AE120_STATE':'ae120','_AE123_LOD_STATE':'ae123_lod',
    '_AE119_TAG':'owned','_AE123_EYE_STATE':'ae123_eye',
})
created=[]
def create_mask(source,settings,actor,uv_layer='UV0'):
    created.append(uv_layer)
    return Material('SaberShader Eye | '+uv_layer,True)
ns['_xdzr8_ae119_material']=create_mask

class TestEyeUV(unittest.TestCase):
    def setUp(self):
        created.clear()
        self.eye=Obj('S_actor_lizhiyan_eyeshadow_01_lod0',['UVMap'])
        self.iris=Obj('S_actor_lizhiyan_iris_01_lod0',['UV0'])
        self.ctx=Ctx([self.iris,self.eye])
        self.settings=types.SimpleNamespace(ae123_eye_full_setup=True,ae123_eye_guard_lods=False)

    def build(self):
        return ns['_xdzr8_ae123_eye_full_setup'](self.ctx,self.settings,[self.eye,self.iris],{'endfield_profile':{'enabled':True}})

    def test_source_uv0_preferred_over_others(self):
        self.assertEqual(ns['_xdzr8_ae123_eye_uv_layer'](Obj('x',['UVMap','UV0'])), ('UV0','EXACT_UV0'))

    def test_sole_existing_layer_is_accepted_without_renaming(self):
        self.assertEqual(ns['_xdzr8_ae123_eye_uv_layer'](self.eye), ('UVMap','SOLE_EXISTING_UV'))
        self.assertEqual([x.name for x in self.eye.data.uv_layers],['UVMap'])

    def test_zero_layers_fail_closed(self):
        self.eye.data.uv_layers=Layers([])
        self.assertEqual(ns['_xdzr8_ae123_eye_uv_layer'](self.eye), ('','NO_UV_LAYERS'))
        result=self.build()
        self.assertEqual(result['overlays'],0)
        self.assertTrue(any('NO_UV_LAYERS' in s for s in result['notes']))
        self.assertFalse(created)

    def test_multiple_layers_fail_closed(self):
        self.eye.data.uv_layers=Layers([Layer('map1'),Layer('UVMap')])
        result=self.build()
        self.assertEqual(result['overlays'],0)
        self.assertTrue(any('AMBIGUOUS_UV_LAYERS' in s for s in result['notes']))

    def test_exact_uv0_build(self):
        self.eye.data.uv_layers=Layers([Layer('UV0')])
        result=self.build()
        self.assertEqual(result['overlays'],1)
        self.assertEqual(created,['UV0'])
        self.assertEqual(self.eye.material_slots[0].link,'OBJECT')

    def test_nonstandard_uv_build_preserves_original_geometry(self):
        orig=self.eye.data.uv_layers
        result=self.build()
        self.assertEqual(result['status'],'VERIFIED')
        self.assertEqual(result['overlays'],1)
        self.assertEqual(created,['UVMap'])
        self.assertIs(self.eye.data.uv_layers,orig)
        self.assertEqual([x.name for x in orig],['UVMap'])
        self.assertEqual(self.eye.material_slots[0].link,'OBJECT')
        self.assertTrue(self.eye.get('ae123_eye'))
        self.assertEqual(json.loads(self.eye['ae123_eye'])['material'],'SaberShader - Eyes')

    def test_repeat_build_idempotent(self):
        ns['_xdzr8_ae125_overlay_uv_correct']=lambda mat,uv: mat.name == 'SaberShader Eye | '+uv
        try:
            self.build()
            result=self.build()
            self.assertEqual(result['overlays'],0)
            self.assertIn('KEEP READY AUTO OVERLAY '+self.eye.name,result['notes'])
            self.assertEqual(created,['UVMap'])
        finally:
            ns['_xdzr8_ae125_overlay_uv_correct']=original_uv_check

    def test_rebuild_wrong_uv_overlay(self):
        ns['_xdzr8_ae125_overlay_uv_correct']=lambda mat,uv: mat.name == 'SaberShader Eye | '+uv
        try:
            self.eye.material_slots[0].material=Material('SaberShader Eye | UV0',True)
            result=self.build()
            self.assertEqual(result['overlays'],1)
            self.assertEqual(created,['UVMap'])
        finally:
            ns['_xdzr8_ae125_overlay_uv_correct']=original_uv_check

    def test_uv_graph_requires_link_to_texture(self):
        uv=types.SimpleNamespace(type='UVMAP',uv_map='UVMap')
        tex=types.SimpleNamespace(type='TEX_IMAGE')
        graph=types.SimpleNamespace(links=[types.SimpleNamespace(from_node=uv,to_node=tex,to_socket=types.SimpleNamespace(name='Vector'),is_valid=True)])
        mat=types.SimpleNamespace(node_tree=graph)
        self.assertTrue(original_uv_check(mat,'UVMap'))
        self.assertFalse(original_uv_check(mat,'UV0'))
        graph.links[0].is_valid=False
        self.assertFalse(original_uv_check(mat,'UVMap'))

    def test_invalid_unrelated_uv_link_does_not_pass(self):
        uv=types.SimpleNamespace(type='UVMAP',uv_map='UVMap')
        tex=types.SimpleNamespace(type='TEX_IMAGE')
        mat=types.SimpleNamespace(node_tree=types.SimpleNamespace(links=[types.SimpleNamespace(from_node=uv,to_node=tex,to_socket=types.SimpleNamespace(name='Color'),is_valid=True)]))
        self.assertFalse(original_uv_check(mat,'UVMap'))

original_uv_check=ns['_xdzr8_ae125_overlay_uv_correct']
if __name__=='__main__': unittest.main()
