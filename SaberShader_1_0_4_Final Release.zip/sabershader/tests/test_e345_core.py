"""Deterministic, Blender-free E3.4.5 safety regression fixtures.
Run: python -m unittest discover -s tests -p 'test_e345_core.py' -v
"""
import copy
import importlib.util
from pathlib import Path
import unittest

p = Path(__file__).resolve().parents[1] / 'ae_fx_cross_validation_core.py'
spec = importlib.util.spec_from_file_location('e345_core_isolated', p)
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)


def snapshot(actor='wulfa', size=1):
    mats = {'fx_orig': {'source': 'M_fx_actor_' + actor + '_demo', 'shader': 'S1', 'fake_user': False}}
    objs = {}
    for i in range(size):
        objs[f'S_actor_{actor}_vfxpart_{i+1:02d}_lod0'] = {
            'actor': actor, 'mesh_data': f'Mesh{i}', 'slots': [
                {'data': 'fx_orig', 'effective': 'fx_orig', 'link': 'DATA'}]}
    objs['S_actor_someother_body_01_lod0'] = {
        'actor': 'someother', 'mesh_data': 'Unrelated', 'slots': [
            {'data': 'normal', 'effective': 'normal', 'link': 'DATA'}]}
    mats['normal'] = {'source': 'body', 'shader': 'S2', 'fake_user': False}
    return {'schema': e.SNAP_SCHEMA, 'actor': actor,
            'source_root': '/source', 'scene_render': {'frame': 1},
            'images': {'ink.png': {'filepath': '/source/ink.png', 'colorspace': 'sRGB'}},
            'objects': objs, 'materials': mats,
            'session': {'kind': '', 'targets': []},
            'audit': {'eligible_preview_slots': 1 if actor != e.SI_ACTOR else 0,
                      'si_preset_leak': False, 'families': {}},
            'build': {'run_id': 'run001', 'run_actor': actor, 'run_event': 'BUILD', 'run_status': 'FINISHED', 'last_result': 'FINISHED'}}


def preview(base):
    current = copy.deepcopy(base)
    current['session']['kind'] = 'E344_SI' if base['actor'] == e.SI_ACTOR else 'E343_UNIVERSAL'
    current['materials']['stage_A2'] = {'source': 'foo', 'shader': 'S3', 'fake_user': True}
    current['materials']['fx_orig']['fake_user'] = True
    for obj, row in current['objects'].items():
        if row['actor'] != base['actor']:
            continue
        row['slots'][0]['data'] = 'stage_A2'
        row['slots'][0]['effective'] = 'stage_A2'
        current['session']['targets'].append({'object': obj, 'slot': 0,
                                               'original': 'fx_orig', 'staged': 'stage_A2',
                                               'current': 'A2'})
    return current


class E345Test(unittest.TestCase):
    def test_e343_preview_passing_isolation(self):
        b = snapshot()
        r = e.compare(b, preview(b), 'PREVIEW_A2')
        self.assertEqual('PASS_STATIC', r['status'])
        self.assertEqual(1, r['preview_target_count'])

    def test_fake_user_only_approved_material(self):
        b = snapshot()
        c = preview(b)
        c['materials']['normal']['fake_user'] = True
        self.assertIn('SOURCE_MATERIAL_MODIFIED', {v['code'] for v in e.compare(b,c,'PREVIEW_A2')['failures']})

    def test_bystander_object_cannot_change(self):
        b = snapshot()
        c = preview(b)
        c['objects']['S_actor_someother_body_01_lod0']['slots'][0]['data'] = 'stage_A2'
        self.assertIn('UNAUTHORIZED_MATERIAL_SLOT_CHANGE', {v['code'] for v in e.compare(b,c,'PREVIEW_A2')['failures']})

    def test_original_graph_mutation_detected(self):
        b = snapshot()
        c = preview(b)
        c['materials']['fx_orig']['shader'] = 'S1_CHANGED'
        self.assertIn('SOURCE_MATERIAL_MODIFIED', {v['code'] for v in e.compare(b,c,'PREVIEW_A2')['failures']})

    def test_image_colorspace_mutation_detected(self):
        b = snapshot()
        c = preview(b)
        c['images']['ink.png']['colorspace'] = 'Non-Color'
        self.assertIn('IMAGES_CHANGED', {v['code'] for v in e.compare(b,c,'PREVIEW_A2')['failures']})

    def test_wrong_character_preset_not_accepted(self):
        b = snapshot()
        c = preview(b)
        c['session']['kind'] = 'E344_SI'
        self.assertIn('PREVIEW_WRONG_KIND', {v['code'] for v in e.compare(b,c,'PREVIEW_A2')['failures']})

    def test_original_restore_exact(self):
        b = snapshot()
        c = copy.deepcopy(b)
        self.assertEqual('PASS_STATIC', e.compare(b,c,'RESTORED')['status'])
        c['materials']['stage_A2'] = {'shader': 'S3'}
        self.assertEqual('FAIL', e.compare(b,c,'RESTORED')['status'])

    def test_repeat_build_requires_distinct_successful_report(self):
        b = snapshot()
        c = copy.deepcopy(b)
        self.assertEqual('FAIL', e.compare(b,c,'REPEAT_BUILD')['status'])
        c['build']['run_id'] = 'run002'
        self.assertEqual('PASS_STATIC', e.compare(b,c,'REPEAT_BUILD')['status'])
        c['build']['run_status'] = 'CANCELLED'
        self.assertEqual('FAIL', e.compare(b,c,'REPEAT_BUILD')['status'])

    def test_si_seven_and_export_cross_character(self):
        si = snapshot(e.SI_ACTOR, 7)
        non = snapshot('wulfa')
        results = {}
        for base in (si, non):
            rp = e.compare(base, preview(base), 'PREVIEW_A2')
            rr = e.compare(base, copy.deepcopy(base), 'RESTORED')
            done = copy.deepcopy(base)
            done['build']['run_id'] = 'run002'
            rb = e.compare(base, done, 'REPEAT_BUILD')
            results[base['actor']] = e.evidence(base['actor'], {'PREVIEW_A2': rp,
                        'RESTORED': rr, 'REPEAT_BUILD': rb}, base)
            self.assertEqual('PASS_STATIC', results[base['actor']]['status'])
        cross = e.compare_characters(results[e.SI_ACTOR], results['wulfa'])
        self.assertEqual('PASS_STATIC', cross['status'])
        self.assertEqual('PENDING_MANUAL_BLENDER_5_1_1', cross['render_validation'])

    def test_cross_character_rejects_missing_provenance(self):
        si = {'schema': e.EVIDENCE_SCHEMA, 'actor': e.SI_ACTOR, 'status': 'PASS_STATIC',
              'fx_audit': {'eligible_preview_slots': 0}}
        other = {'schema': e.EVIDENCE_SCHEMA, 'actor': 'wulfa', 'status': 'PASS_STATIC',
                 'fx_audit': {'eligible_preview_slots': 0}}
        self.assertEqual('INCOMPLETE_OR_FAIL', e.compare_characters(si, other)['status'])
        other['fx_audit']['eligible_preview_slots'] = 1
        self.assertEqual('PASS_STATIC', e.compare_characters(si, other)['status'])
        self.assertEqual('INCOMPLETE_OR_FAIL', e.compare_characters(other, other)['status'])

    def test_missing_phase_never_passes(self):
        b = snapshot()
        report = e.evidence('wulfa', {}, b)
        self.assertEqual('INCOMPLETE_OR_FAIL', report['status'])
        self.assertTrue(report['reasons'])


if __name__ == '__main__':
    unittest.main()
