"""E3.4.6: UI-only tests; does not require bpy or a scene.

The UI must not invoke hidden Build stages from panel draw or remove registered
operators: hiding controls is not the same as deleting the underlying pipeline.
"""
import ast
import importlib.util
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
PANEL_FILES = {
    'ae_source_dictionary.py': 'AEF_PT_ae_si_source_dictionary',
    'ae_fx_universal_e342.py': 'AEF_PT_ae_universal_fx_e342',
    'ae_fx_fidelity_e343.py': 'AEF_PT_ae_fx_e343',
    'ae_si_idle_ink_e344.py': 'AEF_PT_si_idle_ink_e344',
    'ae_fx_cross_validation_e345.py': 'AEF_PT_ae_fx_cross_validation_e345',
}


def _load_visibility():
    spec = importlib.util.spec_from_file_location('sabershader.ae_ui_visibility', ROOT / 'ae_ui_visibility.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _method(file, classname, method):
    tree = ast.parse((ROOT / file).read_text(encoding='utf8'))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == classname)
    return next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method)


class TestAEVisibility(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.visibility = _load_visibility()

    def _context(self, value=None):
        addons = {} if value is None else {
            'sabershader': SimpleNamespace(preferences=SimpleNamespace(show_ae_developer_panels=value))}
        return SimpleNamespace(preferences=SimpleNamespace(addons=addons))

    def test_hidden_by_default(self):
        self.assertFalse(self.visibility.ae_developer_tools_visible(self._context()))
        self.assertFalse(self.visibility.ae_developer_tools_visible(SimpleNamespace()))
        self.assertFalse(self.visibility.ae_developer_tools_visible(self._context(False)))

    def test_opt_in_dev_mode(self):
        self.assertTrue(self.visibility.ae_developer_tools_visible(self._context(True)))
        self.assertFalse(self.visibility.ae_developer_tools_visible(self._context(False)))

    def test_preferences_registered(self):
        source = (ROOT / '__init__.py').read_text()
        self.assertIn('(_ui.AEF_AddonPreferences,) + tuple(', source)
        ui = (ROOT / 'ui.py').read_text()
        self.assertIn('class AEF_AddonPreferences(bpy.types.AddonPreferences):', ui)
        self.assertIn('show_ae_developer_panels: bpy.props.BoolProperty(', ui)
        self.assertIn('default=False', ui)

    def test_external_panels_require_developer_mode(self):
        for filename, classname in PANEL_FILES.items():
            with self.subTest(panel=classname):
                node = _method(filename, classname, 'poll')
                self.assertEqual(len(node.body), 1)
                self.assertIsInstance(node.body[0], ast.Return)
                result = node.body[0].value
                self.assertIsInstance(result, ast.Call)
                self.assertIsInstance(result.func, ast.Name)
                self.assertEqual(result.func.id, 'ae_developer_tools_visible')

    def test_main_panel_uses_developer_gate(self):
        node = _method('ui.py', 'AEF_PT_ui121_endfield', 'draw')
        # Developer tools are accessed only inside an `if developer` branch.
        guarded = [n for n in node.body if isinstance(n, ast.If)
                   and isinstance(n.test, ast.Name) and n.test.id == 'developer']
        self.assertEqual(len(guarded), 1)
        sources = ast.unparse(guarded[0])
        self.assertIn('_sabershader_ae_draw_sections_inline(', sources)
        self.assertIn('_draw_ae_developer_setup(', sources)
        regular = '\n'.join(ast.unparse(n) for n in node.body if n is not guarded[0])
        self.assertNotIn('_sabershader_ae_draw_sections_inline(', regular)
        self.assertNotIn('_draw_ae_developer_setup(', regular)

    def test_public_controls_do_not_expose_json_and_audits(self):
        node = _method('ui.py', 'AEF_PT_ui121_endfield', 'draw')
        public_operator_names = []
        for top in node.body:
            # Only top-level developer branch is excluded.
            if isinstance(top, ast.If) and isinstance(top.test, ast.Name) and top.test.id == 'developer':
                continue
            for n in ast.walk(top):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'operator':
                    if n.args and isinstance(n.args[0], ast.Constant):
                        public_operator_names.append(n.args[0].value)
        for name in public_operator_names:
            with self.subTest(operator=name):
                self.assertNotIn('audit', name)
                self.assertNotIn('snapshot', name)
                self.assertNotIn('export', name)
                self.assertNotIn('e345_cross', name)
        self.assertIn('sabershader.ae129hf4565_select_lod', public_operator_names)
        self.assertIn('sabershader.ae129hf4565_restore_lods', public_operator_names)
        self.assertIn('sabershader.ae_fullsetup_restore', public_operator_names)
        self.assertIn('sabershader.si_vfx_ab_restore', public_operator_names)

    def test_build_and_eye_logic_preserved_after_label_cleanup(self):
        # Code structure is checked independently of display-only captions,
        # module docstrings and operator feedback. See E3.4.5.7 tests.
        from test_e347_naming_cleanup import EXPECTED_LOGIC, normalized_logic_digest
        for filename in ('engine.py', 'ae_one_click.py', 'ae_eye_build_e3454.py'):
            with self.subTest(file=filename):
                self.assertEqual(normalized_logic_digest(filename), EXPECTED_LOGIC[filename])


if __name__ == '__main__':
    unittest.main()
