"""Regression checks for presentation-only naming and code comment cleanup.

No Blender runtime is needed. Baseline digests normalize documented display
metadata and operator feedback, so any changed Build control flow, source
proof, material mutation or restoration logic fails these checks.
"""
import ast
import hashlib
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_LOGIC = {
    'engine.py': 'bd570bc7a9a7f999e659cc162fde955bb6d4cc68a15bc06feeab300cd5a3df00',
    'ae_one_click.py': '7c1a1743bac92ecbba0a38e7d6893a58cae21bd3fa64e460dfee2855ae9bd1e7',
    'ae_eye_build_e3454.py': 'e61037578a2b85506e343bdf8932d004a50c20bcc37920b52a34800010a0203f',
    'ae_full_visual_e3452.py': 'efeb5218108f7e2bd619b9a53638f639f6f78b1bd81a00b7330d4ee2cd322dce',
    'ae_si_build_a_e3451.py': '6903399a77e6c2f7db3d94684bfad5d797087fc129ba9326a30fa15555593838',
}
REVISION_LABEL = re.compile(r'(?i)(?:\bV\d{3,}(?:[_\.]\d+)*\b|\bE3[._]\d[._0-9]*\b|\bAE\d{3,}\b|\bHF\d(?:[._]\d)+\b)')

class _MaskDisplayString(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value, str):
            return ast.copy_location(ast.Constant('<DISPLAY TEXT>'), node)
        return node

class _NormalizePresentation(ast.NodeTransformer):
    def visit_Module(self, node):
        self.generic_visit(node)
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            node.body[0].value.value = '<MODULE DOCUMENTATION>'
        return node

    def visit_Assign(self, node):
        self.generic_visit(node)
        if any(isinstance(t, ast.Name) and t.id in ('bl_label', 'bl_description') for t in node.targets):
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                node.value.value = '<DISPLAY LABEL>'
        return node

    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Attribute):
            if (isinstance(node.func.value, ast.Attribute)
                and isinstance(node.func.value.value, ast.Name)
                and node.func.value.value.id == 'bpy'
                and node.func.value.attr == 'props'
                and node.func.attr.endswith('Property')):
                for kw in node.keywords:
                    if kw.arg in ('name', 'description'):
                        kw.value = _MaskDisplayString().visit(kw.value)
            if node.func.attr == 'report' and len(node.args) >= 2:
                node.args[1] = _MaskDisplayString().visit(node.args[1])
        return node

def normalized_logic_digest(filename):
    tree = _NormalizePresentation().visit(ast.parse((ROOT / filename).read_text(encoding='utf8')))
    return hashlib.sha256(ast.dump(tree, include_attributes=False).encode('utf8')).hexdigest()

class TestNamingAndPreservation(unittest.TestCase):
    def test_build_and_eye_logic_unchanged(self):
        for filename, expected in EXPECTED_LOGIC.items():
            with self.subTest(file=filename):
                self.assertEqual(normalized_logic_digest(filename), expected)

    def test_version_free_display_metadata(self):
        for filename in ('engine.py', 'ae_eye_build_e3454.py', 'ae_fx_universal_e342.py',
                         'ae_si_vfx_ab_e341.py', 'ae_fx_validation.py',
                         'ae_si_idle_ink_e344.py', 'ae_fx_e331.py',
                         'ae_fx_fidelity_e343.py', 'ae_fx_cross_validation_e345.py'):
            tree = ast.parse((ROOT / filename).read_text(encoding='utf8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ('bl_label', 'bl_description') for t in node.targets):
                    if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                        self.assertNotRegex(node.value.value, REVISION_LABEL, (filename, node.lineno))
                if isinstance(node, ast.keyword) and node.arg in ('name', 'description'):
                    if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                        self.assertNotRegex(node.value.value, REVISION_LABEL, (filename, node.lineno))

    def test_build_message_uses_feature_names(self):
        code = (ROOT / 'ae_one_click.py').read_text(encoding='utf8')
        self.assertIn('Si VFX comparison is active', code)
        self.assertIn('Si FX appearance stage failed', code)
        self.assertNotIn("self.report({'ERROR'}, 'Si FX A/B E3.4.1", code)

    def test_legacy_id_and_data_key_preserved(self):
        engine = (ROOT / 'engine.py').read_text(encoding='utf8')
        init = (ROOT / '__init__.py').read_text(encoding='utf8')
        eye = (ROOT / 'ae_eye_build_e3454.py').read_text(encoding='utf8')
        self.assertIn('AEF_SaberShader_V8_Settings', engine)
        self.assertIn('AEF_OT_add_shaders_v11', init)
        self.assertIn('SaberShader_AE_EyeBuildE3454_', eye)
        self.assertIn("REVISION = 'E3455_EYE_UV_LAYER_RECOVERY_1'", eye)

    def test_developer_ui_policy_still_opt_in(self):
        ui = (ROOT / 'ui.py').read_text(encoding='utf8')
        self.assertIn('if developer:', ui)
        self.assertIn('ae_developer_tools_visible(context)', ui)
        self.assertIn('Show AE Developer Tools', ui)

    def test_documentation_explains_safety(self):
        guide = (ROOT / 'DEVELOPER_NOTES.md').read_text(encoding='utf8')
        self.assertIn('Source verification', guide)
        self.assertIn('Do **not** rename `bl_idname`', guide)
        self.assertIn('repeat-build idempotency', guide)

if __name__ == '__main__':
    unittest.main()
