# SaberShader 1.0.4

SaberShader is an independent Blender add-on for stylized character shading,
material and texture recognition, and scene diagnostics. Its supported profiles
include **General / MMD**, **Uma Musume**, **FGO Arcade**, and **Arknights: Endfield**.
It works with user-supplied models and source textures; it does not provide them.

## Installation and safe updating

1. In Blender, use **Edit → Preferences → Add-ons → Install from Disk** and select the SaberShader ZIP.
2. Enable **SaberShader** and open **3D Viewport → Sidebar (N) → SaberShader**.
3. For updates, **disable the old add-on, fully close Blender, replace the installed package, and restart Blender**. Do not keep multiple active copies of the `sabershader` package.
4. Always back up the original `.blend`. Test changes and upgrades on separate copies.

The bundled icon is located at `sabershader/assets/SaberShader_icon.png`.

## Interface and profiles

- **Build SaberShader:** prepares the selected character's material setup from available sources. Confirm the active character and inspect detected materials and textures before building.
- **01 General / MMD:** general stylized shading, material roles, multilingual source-name recognition, texture filename hints, optional manual role assignment and common character tools.
- **02 Eye Tools:** shared eye inspection and repair controls; use the relevant profile-specific tools where applicable.
- **Uma Musume:** anime hair and body shading controls, expression-eye overlays, texture diagnostics and render-matching tools (including **UMA Hair Lab**).
- **FGO Arcade:** source audits, facial materials, UV checks and repairs, lighting, outline and scale controls.
- **Arknights: Endfield:** Face SDF, hair shading, cloth and iris diagnostics, eye repair, LOD guards, outlines and cleanup, grouped into sections such as **Shading & Lighting**, **Face SDF & Hair**, and **Eye Repair & LOD Guard**.
- **05 Texture Intelligence:** shared texture analysis tools and source inspections.
- **06 Advanced & General:** additional diagnostics and general utilities.

The exact controls shown depend on the selected profile, context and supported model data. Some sections are collapsed within a profile panel instead of appearing as separate Blender tabs.

### Material & Texture Dictionary (General / MMD)

Open **General / MMD → Material & Texture Dictionary** to inspect source-name
aliases and possible texture roles. The dictionary supports exact source-name
matches (including imported English and CJK labels), plus optional filename
hints such as `FC_1.jpg`, `face.png`, `Htn_MJ.png`, `MianJu_透.png` and suffixes
like `_HN`, `_P`, `_ST`, `_RS`, `_C`, `_H`, `_S`.

**A filename or suffix is a hint, not proof of a texture channel's meaning.**
Do not assume an unknown imported texture is a normal, mask, roughness or color
map solely from its name, and do not automatically rewire shader inputs on that
basis. The role audit is read-only; applying a role is an explicit operation
that requires an unambiguous source match.

## Recommended workflow

1. Open a **copy** of the scene and select the intended character.
2. Confirm the profile and review the detected objects, materials and source textures.
3. If appropriate, run **Build SaberShader** and inspect the resulting materials.
4. Check facial shading, hair, eyes, outlines, lighting and render color using the relevant profile controls.
5. Save a new `.blend` copy when you need to keep the result; keep the source scene available for comparison.

## Safety and session tools

- **Line Art Diagnostics:** inventories potentially unsafe Grease Pencil Line Art modifiers and can export a JSON report upon request. The inspection does not delete modifiers. The reference build may refuse to continue if it detects a known Line Art risk.
- **Live Sync & Session:** dynamic updates are **off when the add-on starts**. Enabling Live Sync may write shader properties and shape-key values as the scene changes; disabling it does not undo earlier changes.
- **Rescan EyeHideAll:** refreshes the EyeHideAll bindings after importing a character or editing related shape keys. This is an explicit operation that can set shape-key values and supports Undo.
- **JSON export:** reports are not overwritten. On filesystems without hard-link support, the exclusive-copy fallback is **not atomic**, so another process might briefly observe an incomplete destination while it is being copied.

**Important Line Art limitation:** the native Blender Line Art evaluator may still
crash before any Python safety check has a chance to run. The preflight reduces
exposure in supported operations; it **cannot guarantee crash prevention**.
Always work on saved copies and keep an untouched original `.blend`.
See `SAFETY_NOTES.md` for details.

## Optional artwork and rights

**SaberShader is an independent community tool and is not officially affiliated
with, endorsed by or sponsored by the publishers or rights holders** of the
supported games and characters.

**This package does not include extracted game models, textures, animations or
third-party expression-eye artwork.** Optional images and other assets must be
supplied by the user. **Only use files you own or have permission to use.**
Game names, character names and trademarks remain the property of their
respective owners; supporting a profile does not grant rights to third-party
resources. See `THIRD_PARTY_NOTICES.md`.

Repository: https://github.com/XDZR8/SaberShader

## Package layout

```text
sabershader/
  __init__.py           # Add-on metadata and registration
  engine.py             # Shader profiles, material tools and diagnostics
  ui.py                 # Sidebar interface and icon preview
  general_dictionary.py # General/MMD source aliases and filename hints
  handler_dispatch.py   # Live Sync filtering and diagnostic counters
  lifecycle_core.py     # Transactional registration and rollback
  lifecycle_state.py    # Session state
  lifecycle_controls.py # Live Sync controls
  lineart_safety.py     # Line Art risk inspection
  lineart_tools.py      # Line Art diagnostic operators and JSON export
  assets/
    SaberShader_icon.png
  README.md
  RELEASE_NOTES.md
  SAFETY_NOTES.md
  THIRD_PARTY_NOTICES.md
```

## Compatibility and validation

The **public version is 1.0.4**. Some historical numbers remain in operator IDs,
classes, scene/material properties, generated node names and metadata because
they are **compatibility identifiers stored in existing `.blend` projects**.
They do not represent the current version and must not be renamed casually.

This documentation update does not modify Python code or shader algorithms.
SaberShader has passed static checks; full functional and visual compatibility
for every profile still requires tests in Blender on real project copies.
For details, see `RELEASE_NOTES.md`.
