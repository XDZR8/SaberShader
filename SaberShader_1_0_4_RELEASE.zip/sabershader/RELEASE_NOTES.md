# SaberShader 1.0.4 — Release notes

SaberShader offers shader profiles for General/MMD, Uma Musume, FGO Arcade,
Arknights: Endfield and other supported stylized characters.

## Reliability

- Add-on registration is transactional, with rollback if a registration step fails.
- Live Sync is disabled at startup and can be enabled explicitly from the sidebar.
- Scene activation does not automatically delete Line Art modifiers.
- Line Art diagnostic reports are read-only and export without overwriting files.
- The reference build refuses scenes with known Line Art risks rather than deleting modifiers.
- The **Rescan EyeHideAll** button refreshes morph bindings after importing a model;
  it can update shape-key values and supports Undo.
- Cache and event filtering avoid unnecessary work during dynamic updates.
- The module signature rejects mixed cached modules after an in-place upgrade.

## Upgrading

Disable the previous addon, close Blender, replace the installation, then start
Blender again. Never replace the package while it is registered in Blender.
Test with copies of existing `.blend` files before adopting a new package.

## Compatibility

Existing operator IDs, class IDs, Scene/Material properties, material and node
names, and stored metadata with historical revision suffixes remain intact.
Those identifiers are part of the data compatibility contract and should not
be renamed without an explicit, tested migration.

## Validation

This package is based on a functioning RC3 reported by the user. Its editorial
and structural changes were reviewed without native Blender execution in this
environment. Full scene-specific E2/E3 coverage for every profile is not implied.
