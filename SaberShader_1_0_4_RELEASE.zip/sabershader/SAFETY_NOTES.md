# SaberShader — Safety and diagnostics

## Line Art and native Blender crashes

Existing Line Art modifiers are **not automatically deleted** on add-on
activation. Line Art Diagnostics can inspect them without changing the scene,
and the reference build may refuse to proceed when a potentially unsafe
modifier is detected.

**This is a risk-reduction measure, not a guarantee of stability.** A failure
inside Blender's native Line Art evaluator is not ruled out and can close
Blender **before Python code or SaberShader's safety checks can intervene**.
Always test on saved copies and keep an untouched original `.blend`.
A successful static inspection cannot prove that a native crash is impossible.

## Registration and updating

Registration keeps a ledger of its resources and attempts to roll back partial
registration after an error. It should not perform an automatic Line Art
quarantine or material build merely because the add-on is enabled.

When updating, disable SaberShader, **close Blender completely**, replace the
package, then restart. Do not hot-reload registered Blender classes or mix
package files from different builds.

## Live Sync and EyeHideAll

Live Sync starts **disabled for each session**. When enabled, its handlers may
update material properties and shape-key values. Disabling Live Sync stops
future automatic updates; it does **not** reverse earlier changes.

Negative EyeHideAll detection results are cached to avoid rescanning the entire
scene on every frame. After adding a model or relevant shape keys, use
**Rescan EyeHideAll** to refresh the bindings explicitly. Rescanning can apply
the current eye-hide value and supports Undo.

## Exporting diagnostic reports

JSON reports are created without overwriting an existing file. When hard links
are supported, the completed temporary report is published via an exclusive
hard link. If the filesystem does not support hard links, the exclusive-copy
fallback is **not atomic**: another application could briefly read an
incomplete destination during copying. Failed exports attempt to remove only
the partially created destination and their own temporary files.

## Saved projects and third-party assets

Historic operator names, properties and node metadata remain for compatibility
with older `.blend` files. Test upgrades on copies before adopting them.
SaberShader does not grant permission to use game assets; consult
`THIRD_PARTY_NOTICES.md` and use only appropriately licensed resources.
