# Third-party notices

SaberShader is an **independent community add-on**. It is not officially
affiliated with, endorsed by or sponsored by the publishers or rights holders
of games whose styles or asset naming conventions are supported.

Game titles, characters, material names, texture conventions and trademarks
belong to their respective rights holders. A profile name does not imply
affiliation or authorization to extract game resources.

This package does **not** include extracted game models, textures, animations or
third-party expression-eye images. Users must provide any optional resources
separately and only use files they own or have permission to use.
